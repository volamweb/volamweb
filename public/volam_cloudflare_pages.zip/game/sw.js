const C = "jxidle-v339",
  IMG = "jxidle-img-1",
  MAPC = "jxm1-", // per-map caches "jxm1-<id>", created / deleted by js/jxmap.js (LRU of the last 5 maps)
  MAPRE = /^\/map\/(\d+)\//,
  // CDN copy (CHAT_CFG.mapBase, e.g. https://cdn.esport9.com/volam/maps/v1/<id>/…): ciphertext, same per-map caches
  CDNRE = /\/maps\/v[^/]+\/(\d+)\/./,
  ASSET = /\.(png|jpe?g|webp|gif|mp3|ogg|wav|m4a|woff2?|ttf)$/i;
(self.addEventListener("install", (e) => self.skipWaiting()),
  self.addEventListener("activate", (e) =>
    e.waitUntil(
      caches
        .keys()
        .then((t) => Promise.all(t.filter((n) => n !== C && n !== IMG && !n.startsWith(MAPC)).map((n) => caches.delete(n))))
        // map files used to land in the generic image cache: drop them (they live in per-map caches now)
        .then(() => caches.open(IMG))
        .then((s) => s.keys().then((ks) => Promise.all(ks.filter((r) => MAPRE.test(new URL(r.url).pathname)).map((r) => s.delete(r)))))
        .catch(() => {})
        .then(() => self.clients.claim()),
    ),
  ),
  self.addEventListener("fetch", (e) => {
    if (e.request.method !== "GET") return;
    const t = new URL(e.request.url);
    const same = t.origin === location.origin,
      mm = same ? MAPRE.exec(t.pathname) : CDNRE.exec(t.pathname);
    if ((!same && !mm) || t.pathname.startsWith("/sb/") || t.pathname.startsWith("/api/") || t.pathname.startsWith("/adminadmin")) return;
    if (mm) {
      // map files: cache-first, only for maps the page keeps (cache exists); never the generic image cache
      const name = MAPC + mm[1],
        key = t.origin + t.pathname;
      e.respondWith(
        caches.has(name).then((h) =>
          h
            ? caches.open(name).then((s) =>
                s.match(key).then(
                  (c) =>
                    c ||
                    fetch(e.request).then((a) => {
                      a.ok && a.status === 200 && e.waitUntil(s.put(key, a.clone()).catch(() => {}));
                      return a;
                    }),
                ),
              )
            : fetch(e.request),
        ),
      );
      return;
    }
    if (ASSET.test(t.pathname)) {
      e.respondWith(
        caches.open(IMG).then((s) =>
          s.match(e.request).then((c) => {
            const i = fetch(e.request)
              .then((a) => (a.ok && s.put(e.request, a.clone()), a))
              .catch(() => c);
            return c ? (e.waitUntil(i), c) : i;
          }),
        ),
      );
      return;
    }
    const n = /\.(js|css|html)$|\/$/.test(t.pathname);
    e.respondWith(
      fetch(e.request, n ? { cache: "no-cache" } : void 0)
        .then((s) => {
          if (s.ok) {
            const c = s.clone();
            caches.open(C).then((i) => i.put(e.request, c));
          }
          return s;
        })
        .catch(() => caches.match(e.request)),
    );
  }));
