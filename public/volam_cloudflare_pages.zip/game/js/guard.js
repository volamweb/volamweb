"use strict";
const GUARD_KEYS = ["gold", "knb", "lvl", "attrPts", "skPts"],
  GUARD = { sent: {}, q: [], f12: !1 };
function guardOrigin() {
  const n = String(new Error().stack || "")
      .split(
        `
`,
      )
      .slice(1),
    e = location.origin;
  for (const t of n) if (!t.includes("guard.js") && t.includes(e)) return !0;
  return !1;
}
function guardFlag(n, e) {
  const t = Date.now(),
    r = n + ":" + (e.k || "");
  (GUARD.sent[r] && t - GUARD.sent[r] < 10 * 6e4) ||
    ((GUARD.sent[r] = t),
    GUARD.q.push({
      kind: n,
      info: Object.assign(
        { lv: S && S.lvl, cs: S && S.rw && S.rw.stat ? S.rw.stat.reborn | 0 : 0, v: typeof APP_V < "u" ? APP_V : 0 },
        e,
      ),
    }),
    guardSend());
}
async function guardSend() {
  if (!GUARD.q.length || typeof NET > "u" || !NET.user || typeof netCall != "function") return;
  const n = GUARD.q
    .splice(0, 20)
    .map((e) => ({ owner: NET.user.id, name: String((S && S.name) || "").slice(0, 30), kind: e.kind, info: e.info }));
  try {
    await netCall((e) => e.post("/api/flags", { rows: n }));
  } catch {}
}
function guardInstall() {
  if (!(typeof S > "u" || !S || S.__guard === S)) {
    for (const n of GUARD_KEYS) {
      let e = S[n];
      try {
        Object.defineProperty(S, n, {
          configurable: !0,
          enumerable: !0,
          get: () => e,
          set: (t) => {
            const r = e;
            e = t;
            const i = (+t || 0) - (+r || 0);
            i > 0 && ((n === "gold" && i < 5e4) || guardOrigin() || guardFlag("console", { k: n, from: r, to: t }));
          },
        });
      } catch {}
    }
    Object.defineProperty(S, "__guard", { configurable: !0, enumerable: !1, value: S });
  }
}
function guardF12() {
  if (GUARD.f12 || matchMedia("(pointer: coarse)").matches) return;
  const n = window.outerWidth - window.innerWidth,
    e = window.outerHeight - window.innerHeight;
  (n > 200 || e > 260) && ((GUARD.f12 = !0), guardFlag("f12", { k: "f12", w: n, h: e }));
}
setInterval(() => {
  (guardInstall(), guardF12(), guardSend());
}, 2e3);
