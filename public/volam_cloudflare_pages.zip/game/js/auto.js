"use strict";
const AUTO_FORGE_MAX = { fuse: 5, ench: 6, up: 8 };
function enchaseTargets() {
  const t = Object.values(S.eq).filter(Boolean),
    i = t.concat(S.inv, epBox()),
    n = (e) => {
      const o = t.find((s) => s.d === e.d);
      return !o || (!o.set && e.lvl >= o.lvl) ? 1 : 0;
    };
  return i
    .filter(
      (e) =>
        !e.set && e.d >= 0 && e.d <= 9 && e.vio && (e.mag || []).length < vioSlots(e) && (t.includes(e) || reqOk(e)),
    )
    .sort((e, o) => t.includes(o) - t.includes(e) || n(o) - n(e) || o.mag.length - e.mag.length || o.lvl - e.lvl);
}
function findEnchase() {
  const t = Object.keys(mats().ht)
      .map(Number)
      .sort((n, e) => e - n),
    i = Object.keys(mats().ore);
  if (!t.length || !i.length) return null;
  for (const n of enchaseTargets()) {
    const e = n.mag.length;
    for (const o of i)
      if (oreParse(o).place === e) {
        for (const s of t) if (typeof enchaseCheck(n, s, o) != "string") return { it: n, ht: s, key: o };
      }
  }
  return null;
}
const forgeReadyCounts = () => ({
    shard: Object.keys(mats().shard).filter((t) => SHARDS[t] && matHave("shard", t) >= SHARDS[t]).length,
    up: Object.keys(mats().ht)
      .map(Number)
      .filter((t) => t < HT_MAX && matHave("ht", t) >= 3).length,
    ench: findEnchase() ? 1 : 0,
    fuse: fusePick(fusePool()).length === 3 && S.gold >= fuseCost() * 2 ? 1 : 0,
  }),
  AUTO_FUSE_MAX = 10;
function autoFuse(t) {
  if (!S || !S.fac || S.autoFuse === !1 || !verVio()) return 0;
  let i = 0;
  const n = {};
  for (let e = 0; e < AUTO_FUSE_MAX; e++) {
    const o = fusePick(fusePool());
    if (o.length < 3 || S.gold < fuseCost() * 2) break;
    const s = fuse(o);
    if (!s.ok) break;
    (i++, (n[s.lvl] = (n[s.lvl] || 0) + 1));
  }
  return (
    i &&
      ((R.dirty = !0),
      (invDirty = !0),
      t ||
        log(
          `<span class="dim">💎 Tự hợp ${i} Huyền Tinh từ trang sức (${Object.entries(n)
            .map(([e, o]) => `${o} viên cấp ${e}`)
            .join(", ")}).</span>`,
        )),
    i
  );
}
function fusePool() {
  return S.inv
    .concat(typeof epBox == "function" ? epBox() : [])
    .filter(canFuse)
    .filter((t) => !betterThanEquipped(t) && !dtNeed(t))
    .sort((t, i) => itemPower(t) - itemPower(i));
}
function autoPhoi() {
  if (enchaseTargets().length || S.gold < EP_COST.phoi * 3) return !1;
  const t = Object.keys(mats().ht)
    .map(Number)
    .filter((n) => matHave("ht", n) > 0)
    .sort((n, e) => e - n);
  if (!t.length) return !1;
  const i = FAC[S.fac];
  for (const n of Object.values(S.eq)
    .filter((e) => e && !e.vio && !e.set && e.d >= 0 && e.d <= 9)
    .sort((e, o) => itemPower(e) - itemPower(o))) {
    const e = S.inv
      .concat(epBox())
      .filter(
        (s) =>
          s.d === n.d &&
          (s.d > 1 || s.k === n.k) &&
          s.lvl >= n.lvl &&
          !s.set &&
          !s.vio &&
          !s.lock &&
          !s.thanma &&
          (s.r || 0) <= 2 &&
          !dtNeed(s) &&
          reqOk(s) &&
          !(DETAIL_SLOT[s.d] === "weapon" && !weaponFits(s)),
      )
      .sort((s, c) => c.lvl - s.lvl)[0];
    if (!e) continue;
    if (!S.inv.includes(e)) {
      if (S.inv.length >= INV_MAX) continue;
      (itemRemove(e), S.inv.push(e));
    }
    if (makePhoi(e, t[0]).ok) return ((invDirty = !0), !0);
  }
  return !1;
}
function autoForge() {
  return null;
}
const AUTO_BUY_GAIN = 1.25,
  AUTO_BUY_BUDGET = 0.6;
function bestOwnedWeaponDmg() {
  const t = FAC[S.fac];
  let i = 0;
  for (const n of S.inv.concat(S.eq.weapon ? [S.eq.weapon] : []))
    n.d <= 1 &&
      sexOk(n) &&
      (n.req || []).every(([e, o]) => e !== 36 || S.lvl >= o) &&
      weaponFits(n) &&
      (i = Math.max(i, weaponDmg(n)));
  return i;
}
function autoBuyWeapon() {
  const t = FAC[S.fac];
  if (!t || S.autoBuy === !1 || t.wcode < 0 || !J.shops.weapon || S.inv.length >= INV_MAX) return null;
  const i = bestOwnedWeaponDmg();
  let n = null;
  for (const o of J.shops.weapon.items) {
    if (o.g === 1) continue;
    const s = goodsItem(o);
    if (!s || s.d > 1 || !weaponFits(s) || !sexOk(s)) continue;
    const c = shopPrice(o),
      u = weaponDmg(s);
    if (
      c > S.gold * AUTO_BUY_BUDGET ||
      u < i * AUTO_BUY_GAIN ||
      (s.req.find((l) => l[0] === 36) || [0, 0])[1] > eqLevel() ||
      (s.req || []).some(([l, r]) => (l === 37 || l === 39) && r >= 0 && !reqOk(s))
    )
      continue;
    const a = Object.values(reqDeficit(s)).reduce((l, r) => l + r, 0);
    (a > 0 && !(S.autoPts === !0 && a <= S.attrPts + PTS_PER_LEVEL * REQ_SAVE_LEVELS)) ||
      ((!n || u > n.dmg) && (n = { g: o, dmg: u, price: c, need: a }));
  }
  if (!n) return null;
  const e = makeItem(n.g.d, n.g.k, n.g.lvl, 0);
  return e
    ? ((e.s = shopSeries(n.g, e)),
      (S.gold -= n.price),
      addItem(e, !0, !0, !0),
      log(`<span class="dim">Tự mua <b>${esc(e.n)}</b> ở Biện Kinh (${fmtL(n.price)} lượng).</span>`),
      S.autoPts === !0 && autoSpendAttrs(),
      autoEquipAll(),
      (R.dirty = !0),
      (invDirty = !0),
      e)
    : null;
}
const AH_DEF = () => ({ on: !1, minLv: 3, htMax: 4, cap: 3, reserve: 5e4 });
function AH() {
  const t = S.autoHut || (S.autoHut = AH_DEF()),
    i = AH_DEF();
  for (const n in i) t[n] === void 0 && (t[n] = i[n]);
  return t;
}
function ahNeeds() {
  return (typeof enchaseTargets == "function" ? enchaseTargets() : [])
    .slice(0, 3)
    .map((t) => ({
      place: (t.mag || []).length,
      s: t.s,
      d: t.d,
      k: t.k,
      attrs: new Set((t.mag || []).map((i) => i.a)),
    }));
}
function ahPick(t, i, n) {
  let e = null;
  for (let o = 0; o < (t.mag || []).length; o++) {
    const s = t.mag[o];
    if (!hutOk(t, o)) continue;
    const c = hutPlaces(t, o)[0],
      u = hutLevel(s),
      f = c % 2 ? t.s : -1,
      a = n.some(
        (r) =>
          r.place === c &&
          (f < 0 || f === r.s) &&
          !r.attrs.has(s.a) &&
          magicMatchEquip(s.a, r.d, r.k) &&
          magicMatchSeries(s.a, r.s),
      );
    if ((!a && u < i.minLv) || (matHave("ore", oreKey(c, s.a, u, f)) >= i.cap && !a)) continue;
    const l = (a ? 1e3 : 0) + u * 10 + (c % 2 ? 1 : 0);
    (!e || l > e.score) && (e = { i: o, place: c, need: a, lvl: u, score: l });
  }
  return e;
}
function ahHt(t, i) {
  const n = Object.keys(mats().ht)
    .map(Number)
    .filter((e) => e <= i.htMax && matHave("ht", e) > 0)
    .sort((e, o) => e - o);
  if (!n.length) return 0;
  if (t) {
    const e = n.filter((o) => o >= 5);
    if (e.length) return e[0];
  }
  return n[0];
}
function autoHut(t = 10) {
  if (!verVio() || R.dg) return 0;
  const i = AH();
  if (!i.on) return 0;
  const n = ahNeeds(),
    e = epBox()
      .concat(S.inv)
      .filter((r) => canHut(r) && !r.lock && !(typeof dtNeed == "function" && dtNeed(r)) && !lootMatch(r));
  let o = 0,
    s = 0,
    c = 0,
    u = 0,
    f = 0;
  const a = [],
    l = {};
  for (const r of e) {
    if (o >= t || S.gold < i.reserve + hutCost(r)) break;
    const h = ahPick(r, i, n);
    if (!h) {
      if (epBox().includes(r) && (r.r === 1 || r.r === 2)) {
        const g = itemValue(r);
        (itemRemove(r), (S.gold += g), (f += g), u++);
      }
      continue;
    }
    const p = ahHt(h.need, i);
    if (!p) break;
    const d = hutPhoi(r, h.i, h.place, p, { wc: 0, mys: 0, fd: 0 });
    if ((o++, (l[p] = (l[p] || 0) + 1), d.ok))
      (s++, a.push(d.msg.replace(/^Lấy thuộc tính: /, "") + ` (dòng ${h.place + 1})`));
    else if (d.lost) c++;
    else break;
  }
  if (o || u) {
    const r = Object.entries(l)
      .map(([h, p]) => `${p} Huyền Tinh c${h}`)
      .join(", ");
    (log(
      `⚗ Tự rút ${o} món: ${s} đá${a.length ? ` (${a.slice(0, 4).join("; ")}${a.length > 4 ? "…" : ""})` : ""}${c ? `, ${c} thất bại` : ""}${r ? ` · −${r}` : ""}${u ? ` · bán ${u} món không có dòng tốt (+${fmtL(f)} lượng)` : ""}`,
    ),
      (invDirty = !0),
      (R.dirty = !0),
      save());
  }
  return o;
}
