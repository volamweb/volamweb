"use strict";
const CHAT = { sb: null, ch: null, msgs: [], open: !1, unread: 0, online: 0, state: "off", last: 0, err: "" },
  CHAT_MAX = 150,
  CHAT_KEEP = 80,
  CHAT_GAP = 1e4,
  chatCid = () => {
    try {
      let t = localStorage.getItem("jxidle_cid");
      return (
        t ||
          ((t = Math.random().toString(36).slice(2, 12) + Date.now().toString(36)),
          localStorage.setItem("jxidle_cid", t)),
        t
      );
    } catch {
      return "anon" + Math.random().toString(36).slice(2, 10);
    }
  },
  chatName = () => String((S && (S.name || (FAC[S.fac] && FAC[S.fac].n))) || "Vô danh").slice(0, 20),
  chatTime = (t) => {
    const e = new Date(t);
    return `${String(e.getHours()).padStart(2, "0")}:${String(e.getMinutes()).padStart(2, "0")}`;
  };
function chatDom() {
  if ($("#chatBox")) return;
  const t = document.createElement("div");
  ((t.id = "chatBox"),
    (t.innerHTML = `<div id="chatHead"><b>Thế giới</b><small id="chatOn"></small><button id="chatX" title="Thu gọn">▾</button></div>
    <div id="chatLines"></div>
    <form id="chatIn" autocomplete="off"><span id="chatAtt"></span><input id="chatTxt" maxlength="${CHAT_MAX}" placeholder="Nhập tin nhắn…"><button class="btn sm">Gửi</button></form>
    <button id="chatBtn" title="Chat thế giới">💬<b id="chatN"></b></button>`),
    $("#battle").appendChild(t),
    ($("#chatLines").onclick = (e) => {
      const n = e.target.closest("[data-ci]");
      if (n) {
        chatItemShow(+n.dataset.ci);
        return;
      }
      const s = e.target.closest("[data-pn]");
      s && CHAT.open && typeof profileModal == "function" && profileModal(s.dataset.pn);
    }),
    ($("#chatBtn").onclick = () => chatToggle(!0)),
    ($("#chatX").onclick = () => chatToggle(!1)),
    ($("#chatIn").onsubmit = (e) => {
      (e.preventDefault(), chatSend($("#chatTxt").value));
    }));
}
function chatToggle(t) {
  ((CHAT.open = t),
    $("#chatBox").classList.toggle("open", t),
    t &&
      ((CHAT.unread = 0),
      chatPoll(!0),
      setTimeout(() => {
        const e = $("#chatTxt");
        e && !matchMedia("(pointer:coarse)").matches && e.focus();
      }, 0)),
    chatRender());
}
function chatLine(t) {
  return t.sys
    ? `<div class="cl sys">${esc(t.msg)}</div>`
    : `<div class="cl${t.cid === chatCid() ? " me" : ""}${t.pending ? " pend" : ""}"><i>${chatTime(t.ts)}</i> <b data-pn="${esc(t.name)}"${(() => {
        const n = FACTIONS.find((s) => s.n === t.fac);
        return typeof campCol == "function" ? ` style="color:${campCol(n ? n.key : "")}"` : "";
      })()}>${esc(t.name)}</b>${t.lvl ? `<small> ${esc(t.fac || "")} ${t.lvl}</small>` : ""}: ${chatMsgHTML(t)}</div>`;
}
function chatRender() {
  CHAT.rq ||
    (CHAT.rq = requestAnimationFrame(() => {
      ((CHAT.rq = 0), chatRenderNow());
    }));
}
function chatRenderNow() {
  const t = $("#chatBox");
  if (!t) return;
  const e = CHAT.msgs.filter((o) => !chatIsCode(o.msg)),
    n = CHAT.open ? e : e.slice(-4),
    s =
      CHAT.state === "off"
        ? '<div class="cl sys">Chat chưa bật (điền js/chatcfg.js)</div>'
        : CHAT.state === "load"
          ? '<div class="cl sys">Đang kết nối…</div>'
          : CHAT.state === "err"
            ? `<div class="cl sys">Không kết nối được chat${CHAT.err ? ": " + esc(CHAT.err) : ""}</div>`
            : "",
    a = $("#chatLines"),
    i = a.scrollTop + a.clientHeight >= a.scrollHeight - 30,
    c = (CHAT.open || !CHAT.msgs.length ? s : "") + n.map(chatLine).join("");
  (c !== CHAT.lastH && ((CHAT.lastH = c), (a.innerHTML = c), (i || !CHAT.open) && (a.scrollTop = a.scrollHeight)),
    ($("#chatOn").textContent =
      CHAT.state === "ok" && CHAT.online
        ? ` · ${CHAT.online} người online`
        : CHAT.state === "ok" && !CHAT.subOk
          ? " · đang nối…"
          : ""),
    ($("#chatN").textContent = CHAT.unread ? (CHAT.unread > 9 ? "9+" : CHAT.unread) : ""),
    t.classList.toggle("quiet", !CHAT.open && !CHAT.msgs.length && CHAT.state === "off"));
}
function chatPush(t) {
  if (!(t.id && CHAT.msgs.some((e) => e.id === t.id))) {
    if (t.cid === chatCid()) {
      const e = CHAT.msgs.findIndex((n) => n.pending && n.msg === t.msg);
      if (e >= 0) {
        ((CHAT.msgs[e] = t), chatRender());
        return;
      }
    }
    (CHAT.msgs.push(t),
      CHAT.msgs.length > CHAT_KEEP && CHAT.msgs.shift(),
      !CHAT.open && !t.sys && t.cid !== chatCid() && CHAT.unread++,
      chatRender());
  }
}
const CHAT_CODE =
    /^\s*[\/／]|(?<![A-Za-z0-9])[SR]\s*\.\s*[a-z_]{2,}\s*(\[|=|\.|\()|\w\s*=>\s*[\{\w(]|\bconsole\b|localStorage|sessionStorage|\.forEach\s*\(|\bfunction\s*\(|\bdocument\s*\.|\bwindow\s*\.|\beval\s*\(|Object\s*\.\s*(keys|assign|values)/i,
  chatIsCode = (t) => CHAT_CODE.test(String(t || ""));
async function chatSend(t) {
  if (
    ((t = String(t || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, CHAT_MAX)),
    !t && CHAT.att && (t = `[${CHAT.att.n}]`),
    !t)
  )
    return;
  if (chatIsCode(t)) return toast("Không gửi được tin dạng câu lệnh / mã lệnh");
  if (!CHAT.sb) return toast(CHAT.state === "load" ? "Chat đang kết nối, thử lại sau giây lát" : "Chat chưa kết nối");
  if (!hasRealName())
    return nameModal(() => {
      (chatToggle(!0), ($("#chatTxt").value = t));
    });
  if (Date.now() - CHAT.last < CHAT_GAP)
    return toast(`Chờ ${Math.ceil((CHAT_GAP - (Date.now() - CHAT.last)) / 1e3)} giây nữa mới gửi được`);
  if (typeof NET != "undefined" && !NET.user) return toast("Đăng nhập tài khoản (nút 🌐) để chat");
  ((CHAT.last = Date.now()), ($("#chatTxt").value = ""));
  typeof netNeedChar == "function" && (await netNeedChar().catch(() => {}));
  const e = { cid: chatCid(), name: chatName(), fac: FAC[S.fac] ? FAC[S.fac].n : "", lvl: S.lvl | 0, msg: t },
    n = CHAT.att;
  if (n) {
    e.item = n;
    const c = `[${n.n}]`;
    t.includes(c) || (e.msg = (t === c ? "" : t.slice(0, CHAT_MAX - c.length - 1) + " ") + c);
  }
  const s = Object.assign({ id: "tmp" + Date.now(), ts: Date.now(), pending: !0 }, e);
  (CHAT.msgs.push(s), chatAttach(null), chatRender());
  let a = null;
  try {
    a = await API.post("/api/chat", e);
  } catch (i) {
    ((CHAT.msgs = CHAT.msgs.filter((c) => c !== s)),
      chatRender(),
      n && chatAttach(n),
      toast("Gửi lỗi: " + (i.message || "")),
      ($("#chatTxt").value = t),
      (CHAT.last = 0));
    return;
  }
  if (a) {
    const c = CHAT.msgs.indexOf(s);
    (c >= 0 ? (CHAT.msgs.some((o) => o.id === a.id) ? CHAT.msgs.splice(c, 1) : (CHAT.msgs[c] = a)) : chatPush(a),
      chatRender());
  }
}
async function chatInit() {
  if (typeof netOn == "function" && !netOn()) {
    document.body.classList.add("nochat");
    return;
  }
  chatDom();
  if (typeof API == "undefined" || !API.on) {
    ((CHAT.state = "off"), chatRender());
    return;
  }
  ((CHAT.state = "load"), chatRender());
  try {
    CHAT.sb = await netClient();
    const e = await API.get("/api/chat");
    ((CHAT.msgs = e || []),
      (CHAT.state = "ok"),
      chatRender(),
      chatSub(),
      CHAT.polling ||
        ((CHAT.polling = !0),
        setInterval(chatPoll, 1e4),
        document.addEventListener("visibilitychange", () => {
          document.hidden || chatPoll(!0);
        })));
  } catch (e) {
    ((CHAT.state = "err"),
      (CHAT.err = (e.message || String(e)) + " · thử lại sau 10 giây"),
      chatRender(),
      clearTimeout(CHAT.initT),
      (CHAT.initT = setTimeout(chatInit, 1e4)));
  }
}
const CHAT_IT_DROP = new Set(["uid", "lock", "price", "dtk"]);
function chatItemClean(t, e = 0) {
  if (!(e > 4 || t == null)) {
    if (typeof t == "number") return Number.isFinite(t) ? t : void 0;
    if (typeof t == "boolean") return t;
    if (typeof t == "string") return t.slice(0, 60);
    if (Array.isArray(t))
      return t
        .slice(0, 24)
        .map((n) => chatItemClean(n, e + 1))
        .filter((n) => n !== void 0);
    if (typeof t == "object") {
      const n = {};
      let s = 0;
      for (const a in t) {
        if (CHAT_IT_DROP.has(a) || ++s > 30 || !/^\w{1,12}$/.test(a)) continue;
        const i = chatItemClean(t[a], e + 1);
        i !== void 0 && (n[a] = i);
      }
      return n;
    }
  }
}
function chatItemOk(t) {
  return !t ||
    typeof t != "object" ||
    !J.items[t.d] ||
    typeof t.n != "string" ||
    !t.n ||
    ((t = chatItemClean(t)),
    (t.r = clamp(Math.round(+t.r || 0), 0, RAR_COL.length - 1)),
    (t.lvl = clamp(Math.round(+t.lvl || 1), 1, 99)),
    (typeof t.ic != "string" || !/^img\/[\w\/.-]+\.(png|webp|jpg)$/.test(t.ic) || t.ic.includes("..")) && delete t.ic,
    Array.isArray(t.mag) || (t.mag = []),
    (typeof eqBanned == "function" && eqBanned(t)) || (typeof eqRemoved == "function" && eqRemoved(t)))
    ? null
    : t;
}
function chatAttach(t) {
  CHAT.att = t ? chatItemOk(chatItemClean(t)) : null;
  const e = $("#chatAtt");
  if (!e) return;
  e.innerHTML = CHAT.att
    ? `<b style="color:${RAR_COL[CHAT.att.r]}">[${esc(CHAT.att.n)}]</b><button type="button" title="Bỏ đính kèm">✕</button>`
    : "";
  const n = e.querySelector("button");
  n && (n.onclick = () => chatAttach(null));
}
function chatMsgHTML(t) {
  const e = t.item && chatItemOk(t.item);
  let n = esc(t.msg);
  if (e) {
    const s = esc(`[${e.n}]`),
      a = `<a class="chit" data-ci="${+t.id || 0}" style="color:${RAR_COL[e.r]}">${s}</a>`;
    n = n.includes(s) ? n.replace(s, a) : n + " " + a;
  }
  return n;
}
function chatItemShow(t) {
  const e = CHAT.msgs.find((a) => +a.id === t),
    n = e && chatItemOk(e.item);
  if (!n) return;
  let s = "";
  try {
    s = itemHTML(n);
  } catch {
    s = `<h4 style="color:${RAR_COL[n.r]}">${esc(n.n)}</h4><p class="dim">Không đọc được chi tiết món đồ.</p>`;
  }
  modal(`<h3>Đồ của ${esc(e.name)} <small>${esc(e.fac || "")} ${e.lvl || ""}</small></h3>${s}`);
}
function chatShowItem(t) {
  if (document.body.classList.contains("nochat")) return toast("Bản chơi trên máy không có chat");
  if (!$("#chatBox")) return toast("Chat chưa bật");
  (closeModal(!0), chatAttach(t), chatToggle(!0), toast("Đã đính kèm vào chat · gõ thêm lời nhắn rồi bấm Gửi"));
}
if (typeof itemModal == "function") {
  const t = itemModal;
  itemModal = (e, n) => {
    if ((t(e, n), document.body.classList.contains("nochat") || !$("#chatBox"))) return;
    const s = document.querySelector("#mBody .btnrow");
    if (!s || !e) return;
    const a = document.createElement("button");
    ((a.className = "btn"),
      (a.textContent = "💬 Khoe lên chat"),
      (a.onclick = () => chatShowItem(e)),
      s.appendChild(a));
  };
}
const CHAT_RT = !0;
// World chat push: WebSocket /api/chat/ws (server/main.py). Messages {t:"msg", m}, online
// counter {t:"on"|"hello", n|online}; we send {t:"track", cid, name, lvl} for presence.
// CHAT.ch keeps the old channel surface used elsewhere: .state ("joined"/"closed"), .track().
async function chatSub() {
  if (!CHAT_RT) {
    CHAT.subOk = !0;
    return;
  }
  if (!CHAT.sb || CHAT.subBusy) return;
  const t = CHAT.ch;
  if (((CHAT.ch = null), clearTimeout(CHAT.reT), t))
    try {
      t.close();
    } catch {}
  let e;
  try {
    e = new WebSocket(API.wsUrl("/api/chat/ws"));
  } catch {
    return;
  }
  const n = (CHAT.ch = {
    state: "joining",
    track(s) {
      try {
        e.readyState === 1 && e.send(JSON.stringify(Object.assign({ t: "track", cid: chatCid() }, s)));
      } catch {}
    },
    close() {
      ((n.state = "closed"), e.close());
    },
  });
  ((e.onopen = () => {
    CHAT.ch === n &&
      ((n.state = "joined"),
      (CHAT.subOk = !0),
      (CHAT.reN = 0),
      (CHAT.state = "ok"),
      (CHAT.err = ""),
      n.track({ name: chatName(), lvl: (S && S.lvl) | 0 }),
      chatRender());
  }),
    (e.onmessage = (s) => {
      if (CHAT.ch !== n) return;
      let i;
      try {
        i = JSON.parse(s.data);
      } catch {
        return;
      }
      if (i.t === "deploy" || i.t === "hello")
        typeof deployNotice == "function" && deployNotice(i.build, i.t === "deploy");
      i.t === "msg" && i.m
        ? chatPush(i.m)
        : (i.t === "on" || i.t === "hello") && ((CHAT.online = i.n ?? i.online ?? 0), chatRender());
    }),
    (e.onclose = () => {
      CHAT.ch === n &&
        n.state !== "closed" &&
        ((n.state = "closed"),
        (CHAT.subOk = !1),
        chatRender(),
        clearTimeout(CHAT.reT),
        (CHAT.reN = (CHAT.reN || 0) + 1),
        (CHAT.reT = setTimeout(chatSub, Math.min(12e4, 3e3 * 2 ** Math.min(6, CHAT.reN - 1)) + Math.random() * 3e3)));
    }));
}
async function chatPoll(t) {
  if (!CHAT.sb || document.hidden) return;
  const n = CHAT_RT && CHAT.subOk && CHAT.ch && CHAT.ch.state === "joined" ? 6e4 : CHAT.open ? 8e3 : 3e4;
  if (!(t !== !0 && Date.now() - (CHAT.polled || 0) < n)) {
    ((CHAT.polled = Date.now()), CHAT_RT && !CHAT.reN && (!CHAT.ch || CHAT.ch.state === "closed") && chatSub());
    try {
      const s = CHAT.msgs.reduce((i, c) => Math.max(i, +c.id || 0), 0);
      ((await API.get("/api/chat?after=" + s)) || []).forEach(chatPush);
    } catch {}
  }
}
