"use strict";
const BOAT = {
    id: 337,
    n: "Phong Lăng Độ · Thuyền",
    bg: "img/z/337.jpg",
    bgFb: "img/z/336.jpg",
    lo: 1,
    hi: 200,
    m: [674],
    sw: [20, 20, 20, 20, 20],
  },
  BOAT_RUNS = 3,
  BOAT_SEGS = 4,
  BOAT_LIMIT = 240,
  BOAT_LV = 30,
  BOAT_DROP = 5,
  BOAT_TID = 674,
  boatLeft = () => Math.max(0, BOAT_RUNS - (DG().boat || 0)),
  boatOk = () => S.lvl >= BOAT_LV || RW().stat.reborn > 0,
  boatOn = () => !!(R.dg && R.dg.kind === "boat");
function boatMap(n) {
  if (n) {
    const o = Object.assign({}, BOAT, { bg: window.JMO && window.JMO[337] ? BOAT.bg : BOAT.bgFb });
    ((R.zoneShown = "boat"),
      obsLoad(window.JMO && window.JMO[337] ? 337 : 336),
      ([H.x, H.y] = inWorld(
        ...(window.JMO && window.JMO[337]
          ? typeof jxo == "function"
            ? jxo(2150, 1130)
            : [2150, 1130]
          : [WORLD.w / 2, WORLD.h / 2]),
      )),
      snapCamera(),
      (R.bgImg = img(o.bg)),
      playMusic(336));
  } else ((R.zoneShown = null), onZoneChange(zoneOf(Math.min(S.stage, STAGES))));
}
function boatStart() {
  if (dgBusy()) {
    toast(R.deadT > 0 ? "Đang trọng thương, chờ hồi phục" : "Đang ở tháp / phó bản");
    return;
  }
  if (!boatOk()) {
    toast(`Cần cấp ${BOAT_LV}`);
    return;
  }
  if (!boatLeft()) {
    toast("Hết chuyến đò hôm nay");
    return;
  }
  (dgEnterCommon(),
    (R.dg = { kind: "boat", d: { n: "Phong Lăng Độ" }, room: 1, t: 0, limit: BOAT_LIMIT, L: dgLevel(1) }),
    boatMap(!0),
    (R.banner = {
      t: 2.6,
      text: "Phong Lăng Độ",
      sub: `Lên thuyền qua sông · ${BOAT_SEGS} đoạn · Thủy Tặc chặn đường`,
    }),
    log("⛵ Lên thuyền <b>Phong Lăng Độ</b>: Huyền Tinh và đá thuộc tính rơi ×" + BOAT_DROP + " trên thuyền."),
    curTab === "quest" && refresh());
}
function boatSpawn() {
  const n = R.dg,
    o = n.room >= BOAT_SEGS,
    a = (h, s) => {
      const t = rnd(0, Math.PI * 2),
        c = rnd(h, s);
      return inWorld(H.x + Math.cos(t) * c, H.y + Math.sin(t) * c);
    };
  if (o) {
    const [h, s] = a(200, 250),
      t = makeEnemy(BOAT_TID, n.L + 2, "boss", h, s);
    ((t.hp = t.max = t.max * 3), (t.dmg *= 1.2), (t.n = "Thủy Tặc Đầu Lĩnh"), R.enemies.push(t));
    for (let c = 0; c < 3; c++) {
      const [i, u] = a(120, 240),
        e = makeEnemy(BOAT_TID, n.L, "elite", i, u);
      ((e.n = "Thủy Tặc"), R.enemies.push(e));
    }
  } else {
    const h = 5 + n.room;
    for (let s = 0; s < h; s++) {
      const [t, c] = a(120, 280),
        i = makeEnemy(BOAT_TID, n.L, s < n.room ? "elite" : "normal", t, c);
      ((i.n = "Thủy Tặc"), R.enemies.push(i));
    }
  }
}
function boatCleared() {
  const n = R.dg;
  if (n.room >= BOAT_SEGS) {
    boatWin();
    return;
  }
  (n.room++,
    heal(R.P.life * 0.3, !0),
    (R.mana = Math.min(R.P.mana, R.mana + R.P.mana * 0.3)),
    (R.spawnT = 1.6),
    (R.banner = {
      t: 1.4,
      text: `Đoạn sông ${n.room}/${BOAT_SEGS}`,
      sub: n.room >= BOAT_SEGS ? "Thủy Tặc Đầu Lĩnh chặn thuyền!" : "Thủy Tặc nhảy lên thuyền!",
    }));
}
function boatWin() {
  const n = R.dg,
    o = DG();
  o.boat = (o.boat || 0) + 1;
  const a = REC();
  if (
    ((a.boatN = (a.boatN || 0) + 1),
    grant({ gold: 3e3, fd: 10, item: 5, xp: 0.02 }, "Qua sông Phong Lăng Độ"),
    verVio())
  ) {
    const h = clamp(Math.floor(n.L / 15) + 1, 1, HT_MAX);
    matAdd("ht", h, 3);
    const s = [forceOre(n.L), forceOre(n.L)];
    log(`⛵ Thưởng qua sông: 3 Huyền Tinh cấp ${h}, ${s.join(", ")}`);
  }
  (Math.random() < 0.03 && (matAdd("misc", "wc", 1), log("⛵ Nhận 1 Thủy Tinh Trắng")),
    questTick("boat"),
    (R.banner = {
      t: 3,
      text: "Qua sông thành công!",
      sub: `${Math.round(n.t)} giây · còn ${boatLeft()} chuyến hôm nay`,
    }),
    uiSfx("levelup"),
    achCheck(),
    boatExit(),
    save());
}
function boatExit() {
  (dgExit(), boatMap(!1), curTab === "quest" && refresh());
}
const boatDropMul = () => (boatOn() ? BOAT_DROP : 1);
function boatBody() {
  const n = boatOn();
  return `<p class="desc">Lên thuyền Phong Lăng Độ qua sông, Thủy Tặc đánh lên thuyền ${BOAT_SEGS - 1} đợt, đợt cuối là <b>Thủy Tặc Đầu Lĩnh</b>. Nhận nhiệm vụ là <b>tự chuyển lên bản đồ Thuyền</b>.</p>
    <div class="card"><div class="stats"><span>Chuyến còn hôm nay</span><span>${boatLeft()}/${BOAT_RUNS}</span><span>Yêu cầu</span><span>cấp ${BOAT_LV}</span><span>Thời gian</span><span>${BOAT_LIMIT / 60} phút</span><span>Đã qua sông</span><span>${REC().boatN || 0} lần</span></div>
      <div class="small">Trên thuyền: <b class="cp">Huyền Tinh và đá thuộc tính rơi ×${BOAT_DROP}</b>. Qua sông: ${fmtL(3e3 * (1 + S.lvl / 10))} lượng, 10 Phúc Duyên, đồ 5 dòng, 3 Huyền Tinh + 2 đá thuộc tính, 30% Thủy Tinh Trắng. Gục ngã / hết giờ: thất bại, không mất lượt.</div>
      <div class="btnrow">${n ? '<button class="btn red" id="boatOut">Rời thuyền (không mất lượt)</button>' : `<button class="btn" id="boatGo" ${boatOk() && boatLeft() && !dgBusy() ? "" : "disabled"}>${boatOk() ? (boatLeft() ? "⛵ Lên thuyền" : "Hết chuyến hôm nay") : `Cần cấp ${BOAT_LV}`}</button>`}</div></div>`;
}
function bindBoat(n) {
  const o = n.querySelector("#boatGo");
  o &&
    (o.onclick = () => {
      (closeModal(!0), boatStart());
    });
  const a = n.querySelector("#boatOut");
  a &&
    (a.onclick = () => {
      (log("Rời thuyền Phong Lăng Độ."), boatExit());
    });
}
