"use strict";
const STASH_KEY = "jxidle_stash",
  STASH_MAX = 60,
  STASH_V = 1,
  stashNew = () => ({
    v: 1,
    id: Math.random().toString(36).slice(2, 10),
    rev: 0,
    gold: 0,
    items: [],
    mats: { ht: {}, ore: {}, shard: {}, misc: {} },
  });
function stashClean(n) {
  const t = stashNew();
  if (!n || typeof n != "object") return t;
  if (
    ((t.id = typeof n.id == "string" ? n.id : t.id),
    (t.rev = Math.max(0, +n.rev || 0)),
    (t.gold = Number.isFinite(+n.gold) ? Math.max(0, Math.floor(+n.gold)) : 0),
    (t.items = (Array.isArray(n.items) ? n.items : [])
      .filter((s) => s && typeof s == "object" && Array.isArray(s.base) && Array.isArray(s.mag))
      .slice(0, 60)),
    (t.items = t.items.filter((s) => !setNoData(s) && !(typeof eqBanned == "function" && eqBanned(s)))),
    typeof eqRemoved == "function")
  ) {
    let s = 0;
    ((t.items = t.items.filter((e) =>
      eqRemoved(e) ? ((s += typeof itemValue == "function" ? itemValue(e) : 0), !1) : !0,
    )),
      (t.gold += Math.min(2e8, Math.round(s))));
  }
  for (const s of t.items) (s.set && /[\u3400-\u9fff]/.test(s.n) && (s.n = setNameVi(s.n)), setRepair(s));
  for (const s of ["ht", "ore", "shard", "misc"])
    for (const e in (n.mats || {})[s] || {}) {
      const i = Math.floor(+n.mats[s][e]);
      i > 0 && (t.mats[s][e] = i);
    }
  return t;
}
function stashRead() {
  let n = null;
  try {
    n = localStorage.getItem(STASH_KEY);
  } catch {
    return { st: stashNew(), err: "storage" };
  }
  if (!n) return { st: stashNew() };
  const t = (a) => {
      try {
        const r = unpack(a);
        return r.ok ? stashClean(r.state) : null;
      } catch {
        return null;
      }
    },
    s = t(n);
  if (s) return { st: s };
  let e = null;
  try {
    e = localStorage.getItem(STASH_KEY + "_bak");
  } catch {}
  const i = e && t(e);
  return i ? { st: i, restored: !0 } : { st: stashNew(), err: "tampered" };
}
function stashWrite(n) {
  n.rev++;
  const t = localStorage.getItem(STASH_KEY);
  if (t)
    try {
      unpack(t).ok && localStorage.setItem(STASH_KEY + "_bak", t);
    } catch {}
  localStorage.setItem(STASH_KEY, pack(n));
}
function stashTx(n) {
  const { st: t, err: s } = stashRead();
  if (s === "tampered") return { ok: !1, msg: "Kho đã bị chỉnh sửa ngoài game (sai chữ ký), không dùng được" };
  if (s) return { ok: !1, msg: "Không đọc được bộ nhớ trình duyệt" };
  let e;
  try {
    e = n(t);
  } catch (a) {
    return { ok: !1, msg: a.message || "Lỗi kho" };
  }
  if (!e || !e.ok) return e || { ok: !1, msg: "" };
  const i = () => (e.undo && e.undo(), save(), { ok: !1, msg: "Không ghi được kho (bộ nhớ đầy hoặc bị chặn)" });
  if (e.from === "char") {
    save();
    try {
      stashWrite(t);
    } catch {
      return i();
    }
  } else {
    try {
      stashWrite(t);
    } catch {
      return (e.undo && e.undo(), { ok: !1, msg: "Không ghi được kho (bộ nhớ đầy hoặc bị chặn)" });
    }
    save();
  }
  return e;
}
const clone = (n) => JSON.parse(JSON.stringify(n));
function stashDeposit(n) {
  return S.inv.includes(n)
    ? stashTx((t) => {
        if (t.items.length >= 60) return { ok: !1, msg: "Kho đầy (60 món)" };
        const s = clone(n),
          e = S.inv.indexOf(n);
        return (
          S.inv.splice(e, 1),
          t.items.push(s),
          (invDirty = !0),
          {
            ok: !0,
            from: "char",
            msg: `Gửi vào kho: ${n.n}`,
            undo: () => {
              (S.inv.splice(e, 0, n), (invDirty = !0));
            },
          }
        );
      })
    : { ok: !1, msg: "Chỉ gửi được món trong hành trang (không phải đồ đang mặc)" };
}
function stashWithdraw(n) {
  return S.inv.length >= INV_MAX
    ? { ok: !1, msg: "Hành trang đầy" }
    : stashTx((t) => {
        const s = t.items[n];
        return s
          ? (t.items.splice(n, 1),
            (s.uid = S.uid++),
            S.inv.unshift(s),
            (invDirty = !0),
            (R.dirty = !0),
            {
              ok: !0,
              msg: `Lấy ra: ${s.n}`,
              undo: () => {
                S.inv.shift();
              },
            })
          : { ok: !1, msg: "Món không còn trong kho" };
      });
}
function stashGold(n, t) {
  return (
    (t = Math.floor(+t)),
    t > 0
      ? stashTx((s) =>
          n === "in"
            ? t > S.gold
              ? { ok: !1, msg: "Không đủ ngân lượng" }
              : ((S.gold -= t),
                (s.gold += t),
                {
                  ok: !0,
                  from: "char",
                  msg: `Gửi ${fmtL(t)} lượng`,
                  undo: () => {
                    S.gold += t;
                  },
                })
            : t > s.gold
              ? { ok: !1, msg: "Kho không đủ ngân lượng" }
              : ((s.gold -= t),
                (S.gold += t),
                {
                  ok: !0,
                  msg: `Rút ${fmtL(t)} lượng`,
                  undo: () => {
                    S.gold -= t;
                  },
                }),
        )
      : { ok: !1, msg: "Nhập số ngân lượng" }
  );
}
function stashMat(n, t, s, e) {
  return stashTx((i) => {
    const a = n === "in" ? matHave(t, s) : i.mats[t][s] || 0;
    return (
      (e = e == null ? a : Math.min(a, Math.floor(+e))),
      e > 0
        ? (n === "in"
            ? (matAdd(t, s, -e), (i.mats[t][s] = (i.mats[t][s] || 0) + e))
            : ((i.mats[t][s] -= e), i.mats[t][s] <= 0 && delete i.mats[t][s], matAdd(t, s, e)),
          {
            ok: !0,
            from: n === "in" ? "char" : "stash",
            msg: `${n === "in" ? "Gửi" : "Rút"} ${e} ${matName(t, s)}`,
            undo: () => matAdd(t, s, n === "in" ? e : -e),
          })
        : { ok: !1, msg: "Không có gì để chuyển" }
    );
  });
}
function matName(n, t) {
  if (n === "ht") return `Huyền Tinh cấp ${t}`;
  if (n === "shard") return `Mảnh ${t}`;
  if (n === "misc") return miscName(t);
  const s = oreParse(t),
    e = oreRows(s.a)[0];
  return `Khoáng dòng ${s.place + 1} · ${e ? e.n : attrName(s.a)} · cấp ${s.lvl}`;
}
function stashFileText() {
  const { st: n } = stashRead();
  return JSON.stringify({ game: "jxidle-stash", v: 1, exported: Date.now(), data: pack(n) });
}
function parseStashText(n) {
  if (
    ((n = String(n || "")
      .trim()
      .replace(/^﻿/, "")),
    !n)
  )
    throw new Error("File rỗng");
  const t = JSON.parse(n);
  if (!t || t.game !== "jxidle-stash" || typeof t.data != "string") throw new Error("Không phải file kho của game");
  const s = unpack(t.data);
  if (!s.ok) throw new Error("File đã bị chỉnh sửa (sai chữ ký)");
  return stashClean(s.state);
}
function stashImport(n) {
  const t = stashRead(),
    s = stashClean(n);
  s.rev = Math.max(t.st.rev, s.rev);
  try {
    stashWrite(s);
  } catch {
    return { ok: !1, msg: "Không ghi được kho" };
  }
  return { ok: !0, msg: "Đã nạp kho từ file" };
}
let stashTab = "item";
function stashCell(n, t) {
  return `<button class="it r${n.r}${reqOk(n) ? "" : " bad"}" data-si="${t}" title="${esc(n.n)}">${n.ic ? `<img src="${esc(n.ic)}" alt="">` : ""}<i>${n.lvl}</i>${n.s >= 0 ? `<b class="s5" style="background:${SERIES_COL[n.s]}"></b>` : ""}${n.enh ? `<em>+${n.enh}</em>` : ""}</button>`;
}
function stashDone(n, t) {
  (toast(n.msg || (n.ok ? "Xong" : "Không thực hiện được")), n.ok && uiSfx("use"), t !== !1 && stashModal(), refresh());
}
function stashModal(n) {
  n && (stashTab = n);
  const { st: t, err: s } = stashRead(),
    e = [
      ["item", "Đồ"],
      ["mat", "Nguyên liệu"],
      ["gold", "Ngân lượng"],
    ].concat(typeof netOn == "function" && netOn() ? [] : [["file", "File kho"]]);
  stashTab === "file" && e.length < 4 && (stashTab = "item");
  let i = "";
  if (
    (s &&
      (i = `<p class="reqbad">${s === "tampered" ? "Kho đã bị chỉnh sửa ngoài game (sai chữ ký) và không có bản sao lưu hợp lệ. Có thể nạp lại từ file kho." : "Không đọc được bộ nhớ trình duyệt."}</p>`),
    stashTab === "item")
  )
    i += `<p class="desc">Bấm món trong <b>hành trang</b> để gửi vào kho. Bấm món trong <b>kho</b> để xem và lấy ra. Kho dùng chung cho cả 3 slot (${t.items.length}/60 món).</p>
      <h3>Hành trang <small>${S.inv.length}/${INV_MAX}</small></h3><div class="invgrid" id="stInv">${S.inv.map(itemCell).join("") || '<small class="dim">Trống</small>'}</div>
      <h3>Kho chung <small>${t.items.length}/60</small></h3><div class="invgrid" id="stBox">${t.items.map(stashCell).join("") || '<small class="dim">Kho trống</small>'}</div>`;
  else if (stashTab === "mat") {
    const a = [];
    for (const r of ["ht", "ore", "shard", "misc"])
      for (const h of new Set([...Object.keys(mats()[r]), ...Object.keys(t.mats[r])])) a.push([r, h]);
    i +=
      '<p class="desc">Nguyên liệu rèn đang có / trong kho.</p>' +
      (a
        .map(
          ([r, h]) =>
            `<div class="qrow"><span>${esc(matName(r, h))}<small>có ${matHave(r, h)} · kho ${t.mats[r][h] || 0}</small></span><span></span><span class="pm"><button class="btn sm" data-mi="${r}|${h}" ${matHave(r, h) ? "" : "disabled"}>Gửi hết</button><button class="btn sm" data-mo="${r}|${h}" ${t.mats[r][h] ? "" : "disabled"}>Rút hết</button></span></div>`,
        )
        .join("") || '<small class="dim">Chưa có nguyên liệu</small>');
  } else
    stashTab === "gold"
      ? (i += `<p class="desc">Ngân lượng: bạn <b>${fmtL(S.gold)}</b> · kho <b>${fmtL(t.gold)}</b>.</p><div class="row"><input type="number" id="stGold" min="1" placeholder="Số lượng"></div>
      <div class="btnrow"><button class="btn" id="stIn">Gửi vào kho</button><button class="btn" id="stOut">Rút ra</button><button class="btn" id="stInAll">Gửi hết</button><button class="btn" id="stOutAll">Rút hết</button></div>`)
      : (i += `<p class="desc">Chuyển kho sang thiết bị khác: tải file kho (.jxkho) ở đây, nạp ở thiết bị kia. Nạp file sẽ <b>thay thế</b> kho hiện tại. File có chữ ký, sửa tay sẽ bị từ chối.</p>
      <div class="btnrow"><button class="btn" id="stDl">Tải file kho</button><button class="btn red" id="stUp">Nạp file kho</button></div>`);
  modal(
    `<h3>Kho chung <small>${fmtL(t.gold)} lượng · ${t.items.length} món</small></h3><div class="btnrow"><button class="btn sm" id="stDon">🧹 Dọn kho (bán / luyện đồ thừa)</button></div><div class="dtabs" id="stTabs">${e.map(([a, r]) => `<button data-st="${a}" class="${a === stashTab ? "on" : ""}">${r}</button>`).join("")}</div>${i}`,
    () => {
      const a = (o) => document.querySelectorAll("#mBody " + o);
      (((o, l) => {
        const c = $(o);
        c && (c.onclick = l);
      })("#stDon", () => donKhoModal()),
        a("#stTabs [data-st]").forEach((o) => (o.onclick = () => stashModal(o.dataset.st))),
        a("#stInv .it").forEach(
          (o) =>
            (o.onclick = () => {
              const l = S.inv.find((c) => c.uid === +o.dataset.uid);
              l && stashDone(stashDeposit(l));
            }),
        ),
        a("#stBox .it").forEach((o) => (o.onclick = () => stashItemModal(+o.dataset.si))),
        a("[data-mi]").forEach(
          (o) =>
            (o.onclick = () => {
              const [l, c] = o.dataset.mi.split("|");
              stashDone(stashMat("in", l, c));
            }),
        ),
        a("[data-mo]").forEach(
          (o) =>
            (o.onclick = () => {
              const [l, c] = o.dataset.mo.split("|");
              stashDone(stashMat("out", l, c));
            }),
        ));
      const h = () => $("#stGold").value,
        m = (o, l) => {
          const c = $(o);
          c && (c.onclick = l);
        };
      (m("#stIn", () => stashDone(stashGold("in", h()))),
        m("#stOut", () => stashDone(stashGold("out", h()))),
        m("#stInAll", () => stashDone(stashGold("in", S.gold))),
        m("#stOutAll", () => stashDone(stashGold("out", stashRead().st.gold))),
        m("#stDl", () => {
          const o = new Blob([stashFileText()], { type: "application/json" }),
            l = document.createElement("a");
          ((l.href = URL.createObjectURL(o)),
            (l.download = `jxidle_kho_${new Date().toISOString().slice(0, 10)}.jxkho`),
            document.body.appendChild(l),
            l.click(),
            setTimeout(() => {
              (URL.revokeObjectURL(l.href), l.remove());
            }, 1500),
            toast("Đã tải file kho"));
        }),
        m("#stUp", () => {
          const o = document.createElement("input");
          ((o.type = "file"),
            (o.accept = ".jxkho,.json"),
            (o.style.display = "none"),
            (o.onchange = () => {
              const l = o.files && o.files[0];
              if ((o.remove(), !l)) return;
              const c = new FileReader();
              ((c.onload = () => stashImportFlow(String(c.result))), c.readAsText(l));
            }),
            document.body.appendChild(o),
            o.click());
        }));
    },
  );
}
function stashItemModal(n) {
  const t = stashRead().st.items[n];
  if (!t) {
    stashModal();
    return;
  }
  modal(
    `${itemHTML(t)}<div class="btnrow"><button class="btn" id="stTake">Lấy ra</button><button class="btn" id="stBack">Quay lại</button></div>`,
    () => {
      (($("#stTake").onclick = () => stashDone(stashWithdraw(n))), ($("#stBack").onclick = () => stashModal()));
    },
  );
}
function stashImportFlow(n) {
  let t;
  try {
    t = parseStashText(n);
  } catch (e) {
    toast(e.message || "File không hợp lệ");
    return;
  }
  const s = stashRead().st;
  modal(
    `<h3>Nạp file kho</h3><p class="desc">File: <b>${t.items.length}</b> món, <b>${fmtL(t.gold)}</b> lượng. Kho hiện tại: ${s.items.length} món, ${fmtL(s.gold)} lượng. Nạp sẽ <b>thay thế</b> kho hiện tại.</p>
    <div class="btnrow"><button class="btn red" id="stOk">Thay thế kho</button><button class="btn" id="stNo">Hủy</button></div>`,
    () => {
      (($("#stOk").onclick = () => {
        const e = stashImport(t);
        (toast(e.msg), stashModal());
      }),
        ($("#stNo").onclick = () => stashModal("file")));
    },
  );
}
