"use strict";
const LOOK_RAR_A = [0, 0.24, 0.32, 0.4, 0.42, 0.42],
  TM_DUST = { ovan: "#5fb8ff", xtho: "#ff6a3a", tanh: "#f3d35b", dlo: "#6fd46a", cdsu: "#c8965a" },
  HORSE_FX = {
    "Ô Vân Đạp Tuyết": ["#5fb8ff", 3],
    "Xích Thố": ["#ff6a3a", 3],
    "Tuyệt Ảnh": ["#f3d35b", 3],
    "Tuyệt ảnh": ["#f3d35b", 3],
    "Đích Lô": ["#6fd46a", 3],
    "Chiếu Dạ Ngọc Sư Tử": ["#fff1a8", 3],
    "Phi Vân": ["#d8e6ff", 2],
    "Bôn Tiêu": ["#ff9ad0", 2],
    "Xích Long Câu": ["#ff5a3a", 2],
    "Du Huy": ["#c8f0ff", 2],
    "Tuyệt Địa": ["#b48cff", 2],
    "Đằng Vụ": ["#9fd8d0", 2],
    "Siêu Quang": ["#ffe36a", 2],
    "Phiên Vũ": ["#ffb8e8", 3],
    "Hãn Huyết Long Câu": ["#ff3048", 3],
    "Kim Tinh Bạch Hổ Vương": ["#f0f8ff", 3],
    "Phong Vân Thần Mã": ["#ffd24a", 3],
    "Kim Tinh Hổ Vương": ["#ffc84a", 2],
    "Hỏa Tinh Kim Hổ Vương": ["#ff7a2a", 2],
    "Long Tinh Hắc Hổ Vương": ["#9a7aff", 2],
    "Phong Vân Bạch Mã": ["#e8f2ff", 2],
    "Phong Vân Chiến Mã": ["#ffb04a", 2],
    "Sư tử": ["#f3c96a", 1],
    "Lạc đà": ["#d8b47a", 1],
    "Dương Đà": ["#c8a070", 1],
    "Hươu đốm": ["#c89a5a", 1],
    "Dương Sa": ["#e0c090", 1],
    "Ngự Phong": ["#a8e8ff", 1],
    "Truy điện": ["#e8f06a", 1],
    "Lưu Tinh": ["#bfe0ff", 1],
  };
function horseFx(n) {
  if (!n) return null;
  const f = (n.n || "").replace(/\s+\d+$/, ""),
    o = HORSE_FX[f];
  return o || (n.thanma ? [TM_DUST[n.thanma] || "#ffd24a", 3] : null);
}
function partTint(n) {
  if (!n || !reqOk(n)) return null;
  if (n.set) return n.set.kind === "platina" ? { c: "#e6f4ff", a: 0.48 } : { c: "#ffc93c", a: 0.44 };
  const f = LOOK_RAR_A[n.r || 0];
  return f ? { c: n.s >= 0 ? SERIES_COL[n.s] : RAR_COL[n.r], a: f } : null;
}
function heroLook() {
  const n = S.eq,
    f = Object.values(n).filter((c) => c && c.d !== 10),
    o = partTint(n.armor),
    l = partTint(n.helm);
  let e = null;
  if (typeof enoughToActive == "function" && enoughToActive(n)) {
    const c = f.filter((s) => s.set && s.set.kind === "platina").length,
      g = f.filter((s) => s.set && s.set.kind === "gold").length;
    e = c >= g ? { c: "#bfe6ff", c2: "#ffffff", k: 1 } : { c: "#ffb52e", c2: "#fff1a8", k: 1 };
  } else if (f.length >= 5) {
    const c = f.reduce((g, s) => g + (s.enh || 0), 0) / f.length;
    c >= 7 && (e = { c: SERIES_COL[heroSeries()], c2: "#ffffff", k: c >= 9 ? 0.9 : 0.6 });
  }
  const i = n.weapon,
    t = (i && reqOk(i) && i.enh) || 0,
    r = t >= 5 ? { c: i.s >= 0 ? SERIES_COL[i.s] : "#ffe9a8", n: t >= 10 ? 3 : t >= 8 ? 2 : 1 } : null,
    u = n.horse,
    h = horseFx(u),
    a = h ? h[0] : null,
    d = h ? h[1] : 0;
  return { body: o, head: l, aura: e, glow: r, dust: a, hlv: d, key: JSON.stringify([o, l, e, r, a, d]) };
}
const lookOn = () => S && S.lookFx !== !1,
  LOOK_CACHE = new Map();
function tintedFrame(n, f, o, l, e) {
  const i = `${f.f}|${o}|${l}|${e.key}`;
  let t = LOOK_CACHE.get(i);
  if (t) return t;
  ((t = document.createElement("canvas")), (t.width = f.w), (t.height = f.h));
  const r = t.getContext("2d");
  (r.drawImage(n, o * f.w, l * f.h, f.w, f.h, 0, 0, f.w, f.h), (r.globalCompositeOperation = "source-atop"));
  const u = Math.max(0, f.ay - f.h * 0.8),
    h = u + (f.ay - u) * 0.28;
  if (e.body) {
    const a = r.createLinearGradient(0, h - 4, 0, h + 6);
    (a.addColorStop(0, "rgba(0,0,0,0)"),
      a.addColorStop(1, e.body.c),
      (r.globalAlpha = e.body.a),
      (r.fillStyle = a),
      r.fillRect(0, h - 4, f.w, f.h));
  }
  return (
    e.head && ((r.globalAlpha = e.head.a), (r.fillStyle = e.head.c), r.fillRect(0, 0, f.w, h)),
    LOOK_CACHE.size > 600 && LOOK_CACHE.clear(),
    LOOK_CACHE.set(i, t),
    t
  );
}
function drawHeroAnim(n, f, o, l, e, i, t, r = 1) {
  if (typeof jxOn == "function" && jxOn() && R.jx) {
    const s = drawJxHero(f, o, l, e, i, t, r, n);
    if (s) return s;
  }
  const u = R.look;
  if (!lookOn() || !u || (!u.body && !u.head)) return drawAnim(n, f, o, l, e, i, t, r);
  const h = W.anim && W.anim[n];
  if (!h) return !1;
  const a = h[f] || h.st;
  if (!a) return !1;
  const d = img("img/a/" + a.f + SPR_V);
  if (!d.complete || !d.naturalWidth) return !1;
  let c = Math.floor((l * 1e3) / a.ms);
  c = ONCE[f] ? Math.min(c, a.n - 1) : c % a.n;
  const g = animRow(a, o),
    k = t / (a.sc || 1),
    px = k === 1 ? Math.round(e) : e,
    py = k === 1 ? Math.round(i) : i,
    sm = sprCrisp(CX, k);
  return (
    (CX.globalAlpha = r),
    CX.drawImage(tintedFrame(d, a, c, g, u), px - a.ax * k, py - a.ay * k, a.w * k, a.h * k),
    (CX.globalAlpha = 1),
    (CX.imageSmoothingEnabled = sm),
    Math.max(1, a.ay * k)
  );
}
function drawAura(n) {
  const f = R.look;
  if (!lookOn() || !f || !f.aura) return;
  const o = R.clock || 0,
    l = 0.5 + 0.5 * Math.sin(o * 3),
    e = f.aura;
  if (
    (n.save(),
    (n.globalAlpha = (0.35 + 0.25 * l) * e.k),
    (n.strokeStyle = e.c),
    (n.lineWidth = 2),
    n.beginPath(),
    n.ellipse(H.x, H.y, 24 + l * 4, 9 + l * 1.5, 0, 0, 7),
    n.stroke(),
    (n.globalAlpha = 0.18 * e.k),
    (n.fillStyle = e.c),
    n.beginPath(),
    n.ellipse(H.x, H.y, 22, 8, 0, 0, 7),
    n.fill(),
    n.restore(),
    S.lowFx)
  )
    return;
  const i = R.lookP || (R.lookP = []);
  Math.random() < 0.25 * e.k &&
    i.push({
      x: H.x + rnd(-18, 18),
      y: H.y + rnd(-3, 3),
      vy: -rnd(18, 34),
      life: 1.1,
      c: Math.random() < 0.5 ? e.c : e.c2,
    });
}
function drawLookFx(n, f) {
  const o = R.look;
  if (!lookOn() || !o || S.lowFx) {
    R.lookP = null;
    return;
  }
  const l = R.lookP || (R.lookP = []);
  if (o.glow && Math.random() < 0.12 * o.glow.n) {
    const e = rnd(0, 7);
    l.push({
      x: H.x + Math.cos(e) * rnd(8, 20),
      y: H.y - 26 + Math.sin(e) * rnd(6, 16),
      vy: -rnd(6, 16),
      life: 0.7,
      c: o.glow.c,
      s: 1 + o.glow.n * 0.5,
    });
  }
  n.save();
  for (const e of l)
    ((e.life -= f),
      (e.y += e.vy * f),
      (n.globalAlpha = clamp(e.life, 0, 1) * 0.85),
      (n.fillStyle = e.c),
      n.beginPath(),
      n.arc(e.x, e.y, e.s || 1.4, 0, 7),
      n.fill());
  (n.restore(), (R.lookP = l.filter((e) => e.life > 0).slice(-80)));
}
