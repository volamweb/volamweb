"use strict";
const HORSE_LIM = {
    10: 1,
    11: 1,
    271: 1,
    318: 1,
    319: 1,
    29: 1,
    30: 1,
    31: 1,
    35: 1,
    41: 1,
    324: 1,
    323: 1,
    325: 1,
    347: 1,
    303: 1,
    47: 1,
    50: 1,
    54: 1,
    343: 1,
    345: 1,
    349: 1,
    249: 1,
    341: 1,
    339: 1,
    342: 1,
    351: 1,
    68: 1,
    71: 1,
    353: 1,
    85: 1,
    82: 1,
    385: 1,
    88: 1,
    91: 1,
    328: 1,
    380: 1,
    102: 1,
    105: 1,
    113: 1,
    108: 1,
    111: 1,
    336: 1,
    337: 1,
    122: 1,
    125: 1,
    128: 1,
    357: 1,
    359: 1,
    145: 1,
    138: 1,
    148: 1,
    362: 1,
    155: 1,
    158: 1,
    164: 1,
    165: 1,
    267: 1,
    365: 1,
    368: 1,
    179: 1,
    172: 1,
    176: 1,
    182: 1,
    372: 1,
    375: 1,
  },
  RIDE_CD = 0.6,
  skHorseLim = (e) => (e && HORSE_LIM[e.id]) || 0,
  skHorseOk = (e, t = !!R.mounted) => {
    const n = skHorseLim(e);
    return n === 1 ? !t : n === 2 ? t : !0;
  },
  canRide = () => !!(S && S.eq && S.eq.horse && reqOk(S.eq.horse)),
  autoRide = () => S.autoRide !== !1 && !(typeof manual == "function" && manual()),
  curSpeed = () => (R.P ? (R.mounted ? R.P.speed : R.P.speedFoot || R.P.speed) : 1);
function setMount(e, t) {
  return (
    (e = !!e && canRide()),
    !!R.mounted === e || (R.rideCd || 0) > 0
      ? !1
      : ((R.mounted = e),
        (R.rideCd = RIDE_CD),
        (R.dirty = !0),
        refreshRideBtn(),
        !t && typeof uiSfx == "function" && uiSfx("use"),
        !0)
  );
}
function toggleMount() {
  if (!canRide()) {
    toast(S.eq.horse ? "Chưa đủ điều kiện cưỡi ngựa này" : "Chưa có ngựa: mặc ngựa ở ô Ngựa (thẻ Nhân vật)");
    return;
  }
  ((R.rideCd = 0), setMount(!R.mounted));
}
function rideTick(e) {
  if (
    (R.rideCd > 0 && (R.rideCd -= e),
    R.rideCan !== canRide() && ((R.rideCan = canRide()), refreshRideBtn()),
    !canRide())
  ) {
    R.mounted && ((R.mounted = !1), (R.dirty = !0), refreshRideBtn());
    return;
  }
  if (!autoRide() || R.deadT > 0) return;
  const t = R.enemies.some((n) => !n.dead && (!n.home || n.aggro) && jxdE(H, n) < 400);
  // no remount while chasing / fighting (avoids mount <-> dismount flapping for on-foot skills)
  const busy = !!R.moveTo || (R.clock || 0) - (R.tgtHitT ?? -9) < 3;
  !R.mounted && !t && !busy && (H.moving || R.town) && setMount(!0, !0);
}
// The chosen skill needs the other mount state (HORSE_LIM: 1 = on foot only, 2 = mounted only): switch it
// right away, in auto AND manual control, for the main and every disciple (withChar), ignoring the ride
// cooldown — otherwise the main skill silently fell back to the basic attack while staying on the horse.
// null only when a mounted-only skill can't be used (no rideable horse): the caller uses the basic attack.
function rideForAttack(e) {
  const t = SK[e.id];
  if (!t || skHorseOk(t)) return !1;
  const want = !R.mounted;
  if (want && !canRide()) return null;
  R.rideCd = 0;
  return setMount(want, !0) ? !0 : null;
}
function refreshRideBtn() {
  if (typeof pDefer == "function" && pDefer("refreshRideBtn", refreshRideBtn)) return;
  const e = typeof $ == "function" && $("#rideBtn");
  e &&
    ((e.style.display = canRide() ? "" : "none"),
    (e.innerHTML = (R.mounted ? "Xuống ngựa" : "Lên ngựa") + " <small>(M)</small>"),
    e.classList.toggle("on", !!R.mounted));
}
