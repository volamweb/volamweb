"use strict";
const SHOP_TABS = [
    ["weapon", "Vũ khí"],
    ["cloth", "Trang phục"],
    ["jewel", "Trang sức"],
    ["med", "Dược phẩm"],
    ["sell", "Bán đồ"],
  ],
  POT_STACK = 10;
let shopTab = "weapon";
const HORSE_PRICE = { 1: 1e5, 2: 1e5, 3: 3e5, 4: 3e5, 5: 4e5, 6: 4e5, 7: 7e5, 8: 7e5, 9: 1e6, 10: 2e6 };
if (J.shops && J.shops.horse)
  for (const t of J.shops.horse.items) t.g !== 1 && HORSE_PRICE[t.lvl] && (t.price = HORSE_PRICE[t.lvl]);
function shopPrice(t) {
  if (t.g === 1) {
    const o = potionOf(t);
    return Math.round((t.price || (o ? o.price : 50)) * (1 + S.lvl / 25));
  }
  const s = baseRow(t.d, t.k, t.lvl);
  return t.price || (s ? s.price : 100);
}
function potionOf(t) {
  return J.potions.find((s) => s.kind === (t.d === 2 ? "both" : t.d === 1 ? "mana" : "life") && s.tier === t.lvl);
}
const shopSeries = (t, s) => (t.s >= 0 ? t.s : t._s === void 0 ? (t._s = s.s) : t._s);
function goodsItem(t) {
  const s = makeItem(t.d, t.k, t.lvl, 0);
  return s ? (S.uid--, (s.uid = -1), (s.s = shopSeries(t, s)), s) : null;
}
function potStock(t) {
  return ((S.potStock = S.potStock || { life: {}, mana: {} }), S.potStock[t] || (S.potStock[t] = {}));
}
function stockCount(t) {
  return Object.values(potStock(t)).reduce((s, o) => s + o, 0);
}
function takeStock(t) {
  const s = potStock(t),
    o = Object.keys(s)
      .map(Number)
      .filter((n) => s[n] > 0)
      .sort((n, l) => l - n);
  if (!o.length) return null;
  const e = J.potions.find((n) => n.kind === t && n.tier === o[0]);
  return e ? (s[o[0]]--, e) : null;
}
function buyGoods(t) {
  const s = shopPrice(t) * (t.g === 1 ? 10 : 1);
  if (S.gold < s) {
    toast("Không đủ ngân lượng");
    return;
  }
  if (t.g === 1) {
    const o = potionOf(t);
    if (!o) return;
    S.gold -= s;
    const e = potStock(o.kind);
    ((e[o.tier] = (e[o.tier] || 0) + 10), toast(`Mua 10 ${o.n}`), uiSfx("use"));
  } else {
    if (S.inv.length >= INV_MAX) {
      toast("Hành trang đầy");
      return;
    }
    const o = makeItem(t.d, t.k, t.lvl, 0);
    if (!o) return;
    ((o.s = shopSeries(t, o)), (S.gold -= s), addItem(o, !0, !0, !0), toast(`Mua ${o.n}`), uiSfx("dropOther"));
  }
  (save(), shopModal());
}
function shopModal() {
  const t = FAC[S.fac],
    s = SHOP_TABS.filter(([e]) => e === "sell" || (J.shops[e] && J.shops[e].items.length));
  s.find((e) => e[0] === shopTab) || (shopTab = s[0][0]);
  let o = "";
  if (shopTab === "sell") {
    const e = S.inv.filter((n) => !lootMatch(n) && !sellProtected(n));
    o = `<p class="desc">Bán món trong hành trang. Món không khớp bộ lọc: ${e.length} (${fmtL(e.reduce((n, l) => n + itemValue(l), 0))} lượng). Đồ bộ / Tím không bị bán hàng loạt.</p>
      <div class="btnrow"><button class="btn red" id="bSellBad">Bán đồ không khớp lọc</button></div>
      <div class="invgrid">${S.inv.map(itemCell).join("")}</div>`;
  } else {
    const e = J.shops[shopTab].items
      .filter((n) => {
        if (n.g === 1) return !0;
        const l = goodsItem(n);
        return !l || sexOk(l);
      })
      .slice()
      .sort((n, l) => n.d - l.d || n.k - l.k || n.lvl - l.lvl);
    ((o = `<div class="shoplist">${e
      .map((n, l) => {
        if (n.g === 1) {
          const i = potionOf(n);
          return i
            ? `<button class="shoprow" data-i="${l}"><img src="${esc(i.ic || "")}" alt=""><span><b>${esc(i.n)}</b><small>Hồi ${fmt(i.total)} ${i.kind === "mana" ? "nội lực" : "sinh lực"}${i.kind === "both" ? ` + ${fmt(i.mtotal)} nội lực` : ""} trong ${i.dur}s · còn ${potStock(i.kind)[i.tier] || 0}</small></span><em>${fmt(shopPrice(n) * 10)} / 10</em></button>`
            : "";
        }
        const c = goodsItem(n);
        if (!c) return "";
        const r = shopTab === "weapon" && t && weaponFits(c);
        return `<button class="shoprow${reqOk(c) ? "" : " bad"}${r ? " own" : ""}" data-i="${l}"><img src="${esc(c.ic)}" alt=""><span><b>${esc(c.n)}</b><small>Cấp ${c.lvl}${c.s >= 0 ? " · hệ " + SERIES[c.s] : ""}${r ? " · đúng loại vũ khí môn phái" : ""}</small></span><em>${fmt(shopPrice(n))}</em></button>`;
      })
      .join("")}</div>`),
      (R.shopList = e));
  }
  modal(
    `<h3>Cửa hàng ${esc(W.town.n)} <small>${fmtL(S.gold)} lượng</small></h3>
    <div class="dtabs">${s.map(([e, n]) => `<button data-t="${e}" class="${e === shopTab ? "on" : ""}">${n}</button>`).join("")}${typeof npcTownShopId == "function" && npcTownShopId() ? '<button id="bNpcJx">Cửa hàng JX1</button>' : ""}</div>${o}`,
    () => {
      (document.querySelectorAll("#mBody .dtabs button").forEach(
        (n) =>
          (n.onclick = () => {
            ((shopTab = n.dataset.t), shopModal());
          }),
      ),
        document
          .querySelectorAll("#mBody .shoprow")
          .forEach((n) => (n.onclick = () => buyGoods(R.shopList[+n.dataset.i]))));
      const jx = $("#bNpcJx"); // JX1 merchants of this town (js/npcshop.js)
      jx && (jx.onclick = () => npcTownShop("general"));
      const e = $("#bSellBad");
      (e &&
        (e.onclick = () => {
          (sellUnmatched(), save(), shopModal());
        }),
        document.querySelectorAll(".mbox .invgrid .it").forEach(
          (n) =>
            (n.onclick = () => {
              const l = findItem(n.dataset.uid);
              l && (sell(l), (shopTab = "sell"), shopModal());
            }),
        ));
    },
  );
}
