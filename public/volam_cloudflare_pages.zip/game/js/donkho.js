"use strict";
const DK = { inv: !0, box: !0, st: !1, jew: !0, white: !0, blue: !0, gold: !1, vio: !1, lv: 10 },
  dkSafe = (n) =>
    !!n &&
    !n.lock &&
    !n.plv &&
    !n.thanma &&
    !(typeof dtNeed == "function" && dtNeed(n)) &&
    !Object.values(S.eq).includes(n),
  dkJew = (n) => verVio() && FUSE_SLOTS.includes(n.d) && !n.set;
function dkCat(n, i) {
  return !dkSafe(n) ||
    (n.lvl || 1) > DK.lv ||
    (i && !n.set && typeof betterThanEquipped == "function" && betterThanEquipped(n))
    ? ""
    : n.vio
      ? DK.vio && !n.enh
        ? "vio"
        : ""
      : DK.jew && dkJew(n)
        ? "jew"
        : n.set
          ? DK.gold && !setKept(n) && !n.enh
            ? "gold"
            : ""
          : lootMatch(n)
            ? ""
            : (n.r || 0) === 0
              ? DK.white
                ? "white"
                : ""
              : DK.blue
                ? "blue"
                : "";
}
function dkPlan() {
  const n = { inv: [], box: [], st: [], jew: 0, stJew: [], gold: 0 },
    i = (t, o, e) => {
      const s = dkCat(o, e);
      if (s) {
        if (s === "jew") {
          t === "st" ? n.stJew.push(o) : n.jew++;
          return;
        }
        (n[t].push(o), (n.gold += itemValue(o)));
      }
    };
  if (DK.inv) for (const t of S.inv) i("inv", t, !0);
  if (DK.box) for (const t of epBox()) i("box", t, !0);
  if (DK.st) {
    const { st: t, err: o } = stashRead();
    if (!o) for (const e of t.items) i("st", e, !1);
  }
  return n;
}
function dkRun() {
  const n = { moved: 0, fused: 0, sold: 0, gold: 0, msg: [] };
  if (DK.st && DK.jew && verVio()) {
    const t = stashTx((o) => {
      const e = o.items.filter((s) => dkCat(s, !1) === "jew").slice(0, Math.max(0, EP_BOX_MAX - epBox().length));
      if (!e.length) return { ok: !1 };
      o.items = o.items.filter((s) => !e.includes(s));
      for (const s of e) epBox().push(s);
      return {
        ok: !0,
        from: "stash",
        n: e.length,
        undo: () => {
          for (const s of e) {
            const l = epBox().indexOf(s);
            l >= 0 && epBox().splice(l, 1);
          }
        },
      };
    });
    t && t.ok && (n.moved = t.n);
  }
  if (DK.jew && verVio()) {
    const t = {};
    for (let o = 0; o < 200; o++) {
      const e = fusePick(
        fusePool().filter(
          (l) => (l.lvl || 1) <= DK.lv && (DK.inv || !S.inv.includes(l)) && (DK.box || DK.st || !epBox().includes(l)),
        ),
      );
      if (e.length < 3 || S.gold < fuseCost()) break;
      const s = fuse(e);
      if (!s.ok) break;
      (n.fused++, (t[s.lvl] = (t[s.lvl] || 0) + 1));
    }
    n.fused &&
      n.msg.push(
        `luyện ${n.fused} Huyền Tinh (${Object.entries(t)
          .map(([o, e]) => `${e}×c${o}`)
          .join(", ")})`,
      );
  }
  const i = dkPlan();
  for (const [t, o] of [
    ["inv", i.inv],
    ["box", i.box],
  ])
    for (const e of o) {
      const s = t === "inv" ? S.inv : epBox(),
        l = s.indexOf(e);
      if (l < 0) continue;
      s.splice(l, 1);
      const d = itemValue(e);
      ((S.gold += d), (n.gold += d), n.sold++);
    }
  if (DK.st && i.st.length) {
    const t = stashTx((o) => {
      const e = [],
        s = [];
      for (const d of o.items) (dkCat(d, !1) && dkCat(d, !1) !== "jew" ? s : e).push(d);
      if (!s.length) return { ok: !1 };
      const l = s.reduce((d, c) => d + itemValue(c), 0);
      return (
        (o.items = e),
        (S.gold += l),
        {
          ok: !0,
          from: "stash",
          n: s.length,
          v: l,
          undo: () => {
            S.gold -= l;
          },
        }
      );
    });
    t && t.ok && ((n.sold += t.n), (n.gold += t.v));
  }
  return (
    n.moved && n.msg.unshift(`chuyển ${n.moved} trang sức từ Kho chung sang Kho Rèn`),
    n.sold && n.msg.push(`bán ${n.sold} món (+${fmtL(n.gold)} lượng)`),
    (invDirty = !0),
    (R.dirty = !0),
    save(),
    n
  );
}
const dkAllSafe = (n) =>
  !!n && !n.lock && !Object.values(S.eq).includes(n) && !(typeof dtNeed == "function" && dtNeed(n));
function dkAllPlan() {
  const n = { inv: [], box: [], st: [], gold: 0, kind: {} },
    i = (t, o) => {
      if (!dkAllSafe(o)) return;
      (n[t].push(o), (n.gold += itemValue(o)));
      const e =
        o.thanma || (typeof isHorse == "function" && isHorse(o))
          ? "Ngựa"
          : o.vio
            ? "Tím"
            : RAR_VI[o.r || 0] || "Thường";
      n.kind[e] = (n.kind[e] || 0) + 1;
    };
  if (DK.inv) for (const t of S.inv) i("inv", t);
  if (DK.box) for (const t of epBox()) i("box", t);
  if (DK.st) {
    const { st: t, err: o } = stashRead();
    if (!o) for (const e of t.items) i("st", e);
  }
  return n;
}
function dkAllRun() {
  const n = dkAllPlan();
  let i = 0,
    t = 0;
  for (const [o, e] of [
    [S.inv, n.inv],
    [epBox(), n.box],
  ])
    for (const s of e) {
      const l = o.indexOf(s);
      if (l < 0) continue;
      o.splice(l, 1);
      const d = itemValue(s);
      ((S.gold += d), (t += d), i++);
    }
  if (DK.st && n.st.length) {
    const o = stashTx((e) => {
      const s = [],
        l = [];
      for (const c of e.items) (dkAllSafe(c) ? l : s).push(c);
      if (!l.length) return { ok: !1 };
      const d = l.reduce((c, h) => c + itemValue(h), 0);
      return (
        (e.items = s),
        (S.gold += d),
        {
          ok: !0,
          from: "stash",
          n: l.length,
          v: d,
          undo: () => {
            S.gold -= d;
          },
        }
      );
    });
    o && o.ok && ((i += o.n), (t += o.v));
  }
  return ((invDirty = !0), (R.dirty = !0), save(), { n: i, g: t });
}
function donHetModal() {
  const n = dkAllPlan(),
    i = n.inv.length + n.box.length + n.st.length,
    t = [
      DK.inv && `Hành trang ${n.inv.length}`,
      DK.box && `Kho Rèn ${n.box.length}`,
      DK.st && `Kho chung ${n.st.length}`,
    ]
      .filter(Boolean)
      .join(" · "),
    o = ["Tím", "Hoàng Kim", "Bạch Kim", "Ngựa"].filter((e) => n.kind[e]);
  modal(
    `<h3>⚠ Dọn hết</h3>
    <div class="card warnc"><b class="bad">Lưu ý: bán TOÀN BỘ ${i} món, không lấy lại được.</b>
      <div class="small">Không xét bộ lọc, cấp, độ hiếm: bán cả đồ Tím / phôi, Hoàng Kim, ngựa, trang sức.</div>
      <div class="small">Chỉ giữ: món khóa 🔒, đồ đang mặc, đồ cần cho Dã Tẩu.</div></div>
    <table class="dktbl small"><tr><th>Nơi</th><td>${t || "—"}</td></tr>
      <tr><th>Loại</th><td>${
        Object.entries(n.kind)
          .map(([e, s]) => `${e} ${s}`)
          .join(" · ") || "—"
      }</td></tr>
      <tr><th>Nhận</th><td><b>+${fmtL(n.gold)} lượng</b></td></tr></table>
    ${o.length ? `<p class="small bad">Có ${o.map((e) => `${n.kind[e]} ${e}`).join(", ")}: hãy khóa 🔒 món muốn giữ trước khi dọn.</p>` : ""}
    <div class="btnrow"><button class="btn red" id="dhGo" ${i ? "" : "disabled"}>Xác nhận dọn hết ${i} món</button><button class="btn" id="dhNo">Quay lại</button></div>`,
    () => {
      (($("#dhNo").onclick = () => donKhoModal()),
        ($("#dhGo").onclick = () => {
          const e = dkAllRun(),
            s = e.n ? `Dọn hết: bán ${e.n} món (+${fmtL(e.g)} lượng)` : "Không có gì để dọn";
          (toast(s), log(`<span class="dim">🧹 ${s}.</span>`), refresh(), donKhoModal());
        }));
    },
  );
}
function donKhoModal() {
  const { st: n, err: i } = stashRead(),
    t = dkPlan(),
    o = t.stJew.length,
    e = t.jew + o,
    s = Math.floor(e / 3),
    l = (c, h) =>
      `<label class="small" style="display:block"><input type="checkbox" data-dk="${c}" ${DK[c] ? "checked" : ""}> ${h}</label>`,
    d = (c, h, a) => `<tr><td>${c}</td><td>${h}</td><td>${a}</td></tr>`;
  modal(
    `<h3>🧹 Dọn kho</h3>
    <div class="card"><b>Dọn ở đâu</b>
      ${l("inv", `Hành trang <small class="dim">${S.inv.length}/${INV_MAX}</small>`)}
      ${l("box", `Kho Rèn <small class="dim">${epBox().length}/${EP_BOX_MAX}</small>`)}
      ${l("st", `Kho chung <small class="dim">${i ? "không đọc được" : `${n.items.length}/${STASH_MAX}`} · dùng chung 3 nhân vật, xét theo bộ lọc của nhân vật này</small>`)}</div>
    <div class="card"><b>Dọn gì</b>
      ${verVio() ? l("jew", "Nhẫn / dây chuyền / ngọc bội thừa → luyện Huyền Tinh") : ""}
      ${l("white", "Bán đồ trắng")}
      ${l("blue", "Bán đồ xanh không khớp bộ lọc nhặt đồ")}
      ${verVio() ? l("vio", "Bán đồ Tím / phôi Tím (không tốt hơn đồ đang mặc, chưa cường hóa)") : ""}
      ${l("gold", "Bán Hoàng Kim không thuộc bộ đang giữ (bộ phái khác / ngoài danh sách giữ, chưa cường hóa)")}
      <div class="row small">Chỉ dọn món cấp ≤ <select id="dkLv">${Array.from({ length: 10 }, (c, h) => `<option value="${h + 1}" ${DK.lv === h + 1 ? "selected" : ""}>${h + 1}</option>`).join("")}</select></div></div>
    <table class="dktbl small"><tr><th>Nơi</th><th>Bán</th><th>Trang sức luyện</th></tr>
      ${d("Hành trang", DK.inv ? t.inv.length : "—", "")}${d("Kho Rèn", DK.box ? t.box.length : "—", "")}${d("Kho chung", DK.st ? t.st.length : "—", DK.st ? o : "—")}
      ${d("<b>Tổng</b>", `<b>${t.inv.length + t.box.length + t.st.length}</b> (+${fmtL(t.gold)} lượng)`, DK.jew && verVio() ? `<b>${e}</b> → ~${s} Huyền Tinh (${fmtL(fuseCost())}/lần)` : "—")}</table>
    <p class="dim small">Luôn giữ: món khóa 🔒, ${DK.vio ? "" : "đồ Tím / phôi, "}Thần Mã, đồ đang mặc hoặc tốt hơn đồ đang mặc, đồ cần cho Dã Tẩu.</p>
    <div class="btnrow"><button class="btn red" id="dkGo">Dọn ngay</button><button class="btn red" id="dkAll" title="Bán toàn bộ, chỉ giữ món khóa">⚠ Dọn hết</button><button class="btn" id="dkNo">Đóng</button></div>`,
    () => {
      (document.querySelectorAll("#mBody [data-dk]").forEach(
        (c) =>
          (c.onchange = () => {
            ((DK[c.dataset.dk] = c.checked), donKhoModal());
          }),
      ),
        ($("#dkLv").onchange = (c) => {
          ((DK.lv = +c.target.value), donKhoModal());
        }),
        ($("#dkNo").onclick = () => closeModal()),
        ($("#dkAll").onclick = () => donHetModal()),
        ($("#dkGo").onclick = () => {
          const c = dkRun(),
            h = c.msg.length ? "Dọn kho: " + c.msg.join(", ") : "Không có gì để dọn";
          (toast(h), log(`<span class="dim">🧹 ${h}.</span>`), refresh(), donKhoModal());
        }));
    },
  );
}
