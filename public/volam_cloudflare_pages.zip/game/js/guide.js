"use strict";
const TUT = [
  [
    "Hành tẩu tự động",
    "Nhân vật tự đánh quái, nhặt đồ, uống thuốc. Ở thẻ Giang hồ chọn ⚔ Luyện công (đánh ở bãi hợp cấp, tự đổi bãi khi lên cấp) hoặc 📜 Làm nhiệm vụ (tự làm Dã Tẩu, Sát Thủ, đi thuyền, tự chuyển bản đồ). Bạn không cần bấm gì để chơi. Kéo joystick bên trái để tự điều khiển khi muốn; bấm ⚙ Tự động để quay lại.",
    "log",
  ],
  [
    "Trang bị và nhặt đồ",
    "Đồ rơi trên đất, nhân vật tự nhặt món khớp bộ lọc (thẻ Hành trang). Món mạnh hơn được tự mặc (có thể tắt ở thẻ Khác). Bấm vào một món để xem so sánh và lý do thay đổi sức mạnh.",
    "inv",
  ],
  [
    "Điểm tiềm năng và võ công",
    'Mỗi cấp bạn nhận điểm tiềm năng (thẻ Nhân vật) và điểm kỹ năng (thẻ Võ công). Dùng nút + để cộng, − để rút lại, i để xem kỹ năng làm gì, và "Gợi ý" để xem trước cách cộng hiệu quả.',
    "skill",
  ],
  [
    "Rèn đồ",
    'Thẻ Lò rèn, ba chặng: Tím (luyện Huyền Tinh, lấy thuộc tính, chế phôi, khảm nạm), Hoàng Kim Bộ chung / Môn phái (gom mảnh từ trùm). Bật "Tự động rèn đồ" ở thẻ Khác nếu không muốn bấm tay.',
    "forge",
  ],
  [
    "Ép đồ Tím",
    `Thẻ Lò rèn → 💎 Lò Ép Đồ:
1. Tinh luyện: 3 nhẫn / dây chuyền / ngọc bội + 1.000 lượng → 1 Huyền Tinh; 3 viên cùng cấp → 1 viên cấp +1.
2. Lấy thuộc tính: đồ xanh + 1 Huyền Tinh + 5.000 → 1 đá thuộc tính đúng dòng bạn chọn (món nguồn mất).
3. Chế tạo phôi: đồ trắng / xanh + 1 Huyền Tinh + 10.000 → đồ Tím trống, số dòng theo cấp Huyền Tinh (cấp 3 ≈ 5 dòng).
4. Khảm nạm: khảm lần lượt dòng 1 → 6, mỗi dòng 1 đá + 1 Huyền Tinh + 10.000.
Dòng 1/3/5 hiện (Nguyên Khoáng, không phân hệ) · dòng 2/4/6 ẩn (Nguyên Thạch, phải đúng hệ món). Mỗi thuộc tính chỉ 1 lần trên 1 món. Phụ liệu (Thủy Tinh hoặc 5 Phúc Duyên): +15% thành công.`,
    "forge",
  ],
  [
    "Đá thuộc tính và Huyền Tinh ở đâu",
    `ĐÁ THUỘC TÍNH:
• Lấy thuộc tính từ đồ xanh (nguồn chính, chọn được thuộc tính).
• Quái rơi: trùm 20%, tinh anh 3%, quái thường 0,3% (thường hợp hệ / loại đồ đang mặc).
• Phần thưởng phó bản.
HUYỀN TINH:
• Quái rơi: trùm 45%, tinh anh 8%, quái thường 1%.
• Dã Tẩu: 35% mỗi nhiệm vụ, mỗi 10 nhiệm vụ 3 viên. Sát Thủ: mỗi lần hạ 1 viên. Phó bản.
• Luyện từ 3 trang sức thừa.
MẸO: Hành trang → 💎 Đồ để ép Tím: bật tự nhặt đồ trắng, trang sức thừa, đồ xanh có dòng cấp cao; tự cất vào Kho Rèn hoặc Kho chung.`,
    "forge",
  ],
  [
    "Quà và sao lưu",
    "Nút 🎁: điểm danh, mốc cấp, thành tựu, rương Phúc Duyên, sự kiện. Tháp thử thách ở thẻ Nhiệm vụ › Hoạt động; đồ đệ (nhân vật đi theo, mỗi người một hành trang, chuyển đồ bằng nút «Chuyển cho…») ở các thẻ 1 2 3 4 của bảng Nhân vật / Võ công / Hành trang; Chuyển sinh ở thẻ Nhân vật. Game chạy trên máy bạn: hãy vào thẻ Khác → Tải file lưu để sao lưu và chơi trên thiết bị khác.",
    "more",
  ],
];
function tutorialModal(n = 0) {
  const i = TUT[n];
  if (!i) {
    ((S.tut = 1), closeModal(!0), save());
    return;
  }
  (i[2] && curTab !== i[2] && S.fac && showTab(i[2]),
    modal(
      `<h3>${esc(i[0])} <small>${n + 1}/${TUT.length}</small></h3><p class="desc">${esc(i[1]).replace(/\n/g, "<br>")}</p>
    <div class="btnrow">${n > 0 ? '<button class="btn" id="tPrev">Trước</button>' : ""}<button class="btn" id="tNext">${n === TUT.length - 1 ? "Bắt đầu chơi" : "Tiếp"}</button><button class="btn" id="tSkip">Bỏ qua</button></div>`,
      () => {
        const a = $("#tPrev");
        (a && (a.onclick = () => tutorialModal(n - 1)),
          ($("#tNext").onclick = () => tutorialModal(n + 1)),
          ($("#tSkip").onclick = () => {
            ((S.tut = 1), closeModal(!0), save());
          }));
      },
    ),
    (S.tut = 1));
}
const HINTS = {
  pts: 'Bạn có điểm tiềm năng chưa cộng: mở thẻ Nhân vật (nút "Gợi ý" cho cách cộng hiệu quả).',
  skill: "Có điểm kỹ năng: mở thẻ Võ công, bấm i để xem kỹ năng làm gì.",
  forge:
    'Bạn vừa nhặt nguyên liệu rèn (Huyền Tinh / khoáng). thẻ Lò rèn → 💎 Lò Ép Đồ (Huyền Tinh, đá thuộc tính, đồ Tím), hoặc bật "Tự động rèn đồ" ở thẻ Khác.',
  gift: "Có quà chờ nhận ở nút 🎁.",
  full: "Hành trang gần đầy: chỉnh bộ lọc nhặt đồ ở thẻ Hành trang để bớt đồ thừa.",
};
function hint(n) {
  if (!S || !S.fac || R.quiet) return;
  const i = S.hints || (S.hints = {});
  i[n] || !HINTS[n] || ((i[n] = 1), toast(HINTS[n]), log(`<span class="dim">Gợi ý: ${esc(HINTS[n])}</span>`));
}
function checkHints() {
  !S ||
    !S.fac ||
    (S.attrPts > 0 && S.lvl >= 2
      ? hint("pts")
      : S.skPts > 0 && FAC[S.fac].skills.some((n) => canLearn(SK[n]))
        ? hint("skill")
        : Object.keys(mats().ht).length || Object.keys(mats().ore).length
          ? hint("forge")
          : S.inv.length >= INV_MAX - 5 && hint("full"));
}
function todoList() {
  const n = [];
  if (!S || !S.fac) return n;
  (isNovice() &&
    n.push({
      k: "join",
      t: S.lvl >= NOVICE_LV ? "⚑ Gia nhập môn phái" : `Cấp ${NOVICE_LV}: gia nhập môn phái`,
      go: () => joinModal(),
    }),
    S.attrPts > 0 && n.push({ k: "attr", t: `${S.attrPts} điểm tiềm năng`, go: () => showTab("char") }),
    S.skPts > 0 &&
      FAC[S.fac].skills.some((t) => canLearn(SK[t])) &&
      n.push({ k: "skill", t: `${S.skPts} điểm kỹ năng`, go: () => showTab("skill") }));
  const i = S.inv.filter((t) => betterThanEquipped(t)).length;
  (i && n.push({ k: "gear", t: `${i} món mạnh hơn đồ đang mặc`, go: () => showTab("inv") }),
    typeof dgPending == "function" &&
      dgPending() &&
      n.push({ k: "wb", t: "Rương Boss tuần chờ nhận", go: () => actModal("wb") }),
    ghTodo(n),
    S.fac &&
      typeof hasRealName == "function" &&
      !hasRealName() &&
      n.push({ k: "name", t: "✏ Đặt tên nhân vật", go: () => nameModal() }),
    giftPending() && n.push({ k: "gift", t: "Có quà chờ nhận", go: () => giftModal(!0) }));
  const a = forgeReadyCounts();
  return (
    a.shard + a.up + a.ench + a.fuse &&
      !S.autoForge &&
      n.push({
        k: "forge",
        t: `Rèn đồ: ${[a.shard && "ghép mảnh", a.ench && "khảm", a.fuse && "hợp Huyền Tinh", a.up && "thăng cấp"].filter(Boolean).join(", ")}`,
        go: () => (a.ench || a.fuse || a.up ? epModal(a.ench ? "kham" : "tl") : htModal()),
      }),
    S.inv.length >= INV_MAX - 3 && n.push({ k: "full", t: "Hành trang gần đầy", go: () => showTab("inv") }),
    S.lvl >= 5 &&
      !(typeof netOn == "function" && netOn()) &&
      Date.now() - (S.bakAt || 0) > 7 * 864e5 &&
      n.push({ k: "bak", t: "Nên tải file sao lưu", go: () => showTab("more") }),
    n
  );
}
function todoHTML() {
  const n = todoList();
  return n.length
    ? `<div class="todo" id="todoBox"><b>Việc cần làm</b>${n.map((i, a) => `<button class="chip2 todochip" data-i="${a}">${esc(i.t)}</button>`).join("")}</div>`
    : "";
}
function bindTodo() {
  const n = todoList();
  document.querySelectorAll("#todoBox .todochip").forEach(
    (i) =>
      (i.onclick = () => {
        const a = n[+i.dataset.i];
        a && a.go();
      }),
  );
}
function powerBreakdown() {
  const n = R.P,
    i = S.lvl,
    a = 8 + 3.2 * i,
    c = 30 + 9 * i,
    t = n.main,
    h = t.useAR ? hitPercent(n.ar, a, t.ignore) / 100 : 1,
    s = 1 - hitPercent(c, n.def) / 100,
    l = ELEM.reduce((o, e) => o + n.res[e], 0) / ELEM.length,
    r = {
      power: power(n),
      dps: t.dps * h,
      hit: h,
      dodge: s,
      avgRes: l,
      ehp: n.life / Math.max(0.2, 1 - l / 100) / Math.max(0.3, 1 - s),
      main: t.n,
    },
    g = power(calc(S.eq)),
    u = [];
  for (const [o, e] of SLOTS) {
    const m = S.eq[o];
    if (!m) continue;
    const p = Object.assign({}, S.eq);
    (delete p[o], u.push({ n: e, name: m.n, v: g / Math.max(1, power(calc(p))) - 1 }));
  }
  const d = [];
  for (const o of Object.keys(ATTR_VI)) {
    const e = S.attr[o];
    if (!e) continue;
    S.attr[o] = 0;
    let m;
    try {
      m = power(calc(S.eq));
    } finally {
      S.attr[o] = e;
    }
    d.push({ n: ATTR_VI[o], pts: e, v: g / Math.max(1, m) - 1 });
  }
  return { info: r, slots: u.sort((o, e) => e.v - o.v), attrs: d.sort((o, e) => e.v - o.v) };
}
function powerModal() {
  const n = powerBreakdown(),
    i = n.info,
    a = (t) => (t * 100).toFixed(1) + "%",
    c = (t, h, s) =>
      `<span>${esc(t)}${s ? ` <small class="dim">${esc(s)}</small>` : ""}</span><span class="${h > 5e-4 ? "cp" : "dim"}">${h > 0 ? "+" : ""}${a(h)}</span>`;
  modal(`<h3>Lực chiến ${fmt(R.power)}</h3>
    <p class="desc">Lực chiến = DPS thực tế<sup>0,7</sup> × máu hiệu dụng<sup>0,3</sup>, tính so với quái cùng cấp (${S.lvl}), rồi quy đổi theo môn phái để cùng cấp, chưa mặc đồ thì các phái ngang nhau. Mỗi dòng dưới đây là mức lực chiến sẽ <b>mất</b> nếu bỏ đi thành phần đó.</p>
    <div class="card stats"><span>Chiêu chính</span><span>${esc(i.main)}</span><span>DPS thực tế</span><span>${fmt(i.dps)}</span><span>Tỉ lệ trúng quái cùng cấp</span><span>${Math.round(i.hit * 100)}%</span>
      <span>Máu hiệu dụng</span><span>${fmt(i.ehp)}</span><span>Kháng trung bình</span><span>${Math.round(i.avgRes)}%</span><span>Quái bị né</span><span>${Math.round(i.dodge * 100)}%</span></div>
    <h3>Từ trang bị</h3><div class="card stats">${n.slots.map((t) => c(t.n, t.v, t.name)).join("") || '<span class="dim">Chưa mặc gì</span>'}</div>
    <h3>Từ điểm tiềm năng đã cộng</h3><div class="card stats">${n.attrs.map((t) => c(t.n, t.v, t.pts + " điểm")).join("") || '<span class="dim">Chưa cộng điểm</span>'}</div>`);
}
function snapPts() {
  return {
    sk: Object.assign({}, S.sk),
    skPts: S.skPts,
    attr: Object.assign({}, S.attr),
    attrPts: S.attrPts,
    main: S.main,
    mainLock: S.mainLock,
  };
}
function restorePts(n) {
  ((S.sk = Object.assign({}, n.sk)),
    (S.skPts = n.skPts),
    (S.attr = Object.assign({}, n.attr)),
    (S.attrPts = n.attrPts),
    (S.main = n.main),
    (S.mainLock = n.mainLock),
    (R.dirty = !0),
    recalc());
}
function spendAttrsGreedy() {
  let n = fillGearReq();
  for (; S.attrPts > 0;) {
    const i = power(calc());
    let a = "vit",
      c = -1 / 0;
    for (const t of ["str", "dex", "vit", "eng"]) {
      S.attr[t]++;
      const h = power(calc()) - i;
      (S.attr[t]--, h > c && ((c = h), (a = t)));
    }
    (S.attr[a]++, S.attrPts--, n++);
  }
  return (n && (R.dirty = !0), n);
}
function suggestPlan() {
  const n = snapPts(),
    i = power(calc()),
    a = { skills: [], attrs: [], gainSk: 0, gainAt: 0 },
    c = JSON.stringify(S.skL || {});
  ((R.sim = 1), (R.buffAssume = !0));
  try {
    if (S.skPts > 0) {
      const t = Object.assign({}, S.sk);
      autoSpendSkills();
      for (const h in S.sk) {
        const s = S.sk[h] - (t[h] || 0);
        s > 0 && a.skills.push({ id: +h, n: SK[h].n, d: s, to: S.sk[h], max: SK[h].max });
      }
      a.gainSk = power(calc()) / Math.max(1, i) - 1;
    }
    if ((restorePts(n), S.attrPts > 0)) {
      const t = Object.assign({}, S.attr);
      spendAttrsGreedy();
      for (const h of Object.keys(ATTR_VI)) {
        const s = S.attr[h] - t[h];
        s > 0 && a.attrs.push({ k: h, n: ATTR_VI[h], d: s });
      }
      a.gainAt = power(calc()) / Math.max(1, i) - 1;
    }
  } finally {
    ((R.buffAssume = !1), restorePts(n), (R.sim = 0), (S.skL = JSON.parse(c)));
  }
  return a;
}
function suggestModal() {
  const n = suggestPlan(),
    i = (s) => (s >= 0 ? "+" : "") + (s * 100).toFixed(1) + "%",
    a = n.skills.length
      ? `<div class="card"><b>Võ công</b> <small class="cp">sức mạnh ${i(n.gainSk)}</small>${n.skills.map((s) => `<div>${esc(s.n)}: +${s.d} → ${s.to}/${s.max}</div>`).join("")}<div class="btnrow"><button class="btn" id="sgSk">Áp dụng</button></div></div>`
      : "",
    c = gearReqPlan(),
    t = c.total
      ? `<div class="card"><b>Đủ điểm cho đồ đang mặc</b> <small class="dim">cần ${c.total} điểm · đang có ${S.attrPts}${c.total > S.attrPts ? ` · thiếu ${c.total - S.attrPts} (≈ ${Math.ceil((c.total - S.attrPts) / PTS_PER_LEVEL)} cấp nữa)` : ""}</small>${c.list
          .map(
            (s) =>
              `<div class="small">${esc(s.it.n)} <span class="dim">(cấp ${s.lv})</span>: ${Object.entries(s.d)
                .map(([l, r]) => `${ATTR_VI[l]} +${r}`)
                .join(", ")}</div>`,
          )
          .join(
            "",
          )}<div class="dim small">Gợi ý tiềm năng bên dưới cộng phần này trước, phần còn lại theo lực chiến.</div></div>`
      : "",
    h = n.attrs.length
      ? `<div class="card"><b>Tiềm năng</b> <small class="cp">sức mạnh ${i(n.gainAt)}</small>${n.attrs.map((s) => `<div>${s.n}: +${s.d}</div>`).join("")}<div class="btnrow"><button class="btn" id="sgAt">Áp dụng</button></div></div>`
      : "";
  modal(
    `<h3>Gợi ý cộng điểm</h3><p class="desc">Xem trước, chưa cộng gì. Gợi ý chọn cách tăng sức mạnh nhiều nhất với trang bị hiện tại. Bạn vẫn rút điểm được bằng nút −.</p>${a}${t}${h}${!a && !h ? '<p class="dim">Bạn không có điểm nào để cộng.</p>' : ""}`,
    () => {
      const s = $("#sgSk");
      s &&
        (s.onclick = () => {
          (autoSpendSkills(), recalc(), save(), refresh(), suggestModal());
        });
      const l = $("#sgAt");
      l &&
        (l.onclick = () => {
          (spendAttrsGreedy(), recalc(), save(), refresh(), suggestModal());
        });
    },
  );
}
let codexTab = "zone";
function codexModal(n) {
  n && (codexTab = n);
  const i = [
    ["zone", "Vùng và quái"],
    ["set", "Bộ Hoàng Kim"],
    ["mat", "Nguyên liệu rèn"],
  ];
  let a = "";
  if (codexTab === "zone")
    a = ZONES.map((c, t) => {
      const h = S.maxStage >= t * ZONE_STAGES + 1,
        s = c.m
          .filter((l) => MON[l])
          .map((l) => esc(MON[l].n))
          .join(", ");
      return `<div class="card${h ? "" : " lock"}"><b>${esc(c.n)}</b> <small class="dim">cấp ${c.lo}–${c.hi}${h ? "" : " · chưa tới"}</small><br><small>Trùm: <b class="boss">${esc((MON[c.boss] || {}).n || "?")}</b></small><br><small class="dim">Quái: ${s}</small><br><small>Ngũ hành: ${
        c.sw
          .map((l, r) => (l ? `<span style="color:${SERIES_COL[r]}">${SERIES[r]}</span>` : ""))
          .filter(Boolean)
          .join(" ") || "—"
      }</small></div>`;
    }).join("");
  else if (codexTab === "set") {
    const c = FAC[S.fac] ? FAC[S.fac].id : -1,
      t = new Map();
    for (const s of J.sets.gold) {
      if (!sexReqOk(s.req) || !setRowOk(s)) continue;
      const l = reqOfRow(s, 39);
      (l !== c && l !== -1) || (t.get(s.grp) || t.set(s.grp, []).get(s.grp)).push(s);
    }
    const h = [...t.values()].sort((s, l) => reqOfRow(s[0], 36) - reqOfRow(l[0], 36));
    a =
      `<p class="desc">Bộ Hoàng Kim của phái bạn (${h.length} bộ). Mặc đủ số món của một bộ sẽ mở hết dòng ẩn của mọi trang bị.</p>` +
        h
          .map((s) => {
            const l = s[0],
              r = l.n2 || 99;
            return `<div class="card"><b>${esc(l.n.split(" ").slice(0, 2).join(" "))}…</b> <small class="dim">cấp ${reqOfRow(l, 36)} · ${s.length} món · đủ ${r} món mở dòng ẩn</small><br><small class="dim">${s.map((g) => esc(g.n)).join(" · ")}</small></div>`;
          })
          .join("") || '<p class="dim">Không có.</p>';
  } else {
    const c = (t) =>
      `${Math.round(DROP[t].boss * 1e3) / 10}% trùm · ${Math.round(DROP[t].elite * 1e3) / 10}% tinh anh · ${Math.round(DROP[t].normal * 1e4) / 100}% quái thường`;
    a = `<div class="card"><b>Chuỗi rèn</b><br><small>Tím (Lò rèn → Lò Ép Đồ): tinh luyện Huyền Tinh (3 trang sức + ${fmtL(fuseCost())}; 3 viên cùng cấp → 1, thất bại mất 1 viên) → lấy thuộc tính từ đồ xanh thành đá (5.000) → chế tạo phôi Tím trống (10.000, số dòng theo cấp Huyền Tinh) → khảm nạm lần lượt từng dòng (10.000; dòng ẩn đúng hệ; không trùng thuộc tính).<br>Hoàng Kim: gom mảnh từ trùm (9 / 6 / 4 mảnh) ghép thành món bộ.</small></div>
      <div class="card"><b>Huyền Tinh Khoáng Thạch</b> <small class="dim">đang có ${Object.values(mats().ht).reduce((t, h) => t + h, 0)}</small><br><small>Rơi: ${c("ht")} · Dã Tẩu (35% mỗi nhiệm vụ, mỗi 10 nhiệm vụ 3 viên) · Sát Thủ · phó bản · luyện 3 nhẫn / dây chuyền / ngọc bội (Lò rèn → Tinh luyện)</small></div>
      <div class="card"><b>Đá thuộc tính (dòng 1–6)</b> <small class="dim">đang có ${Object.values(mats().ore).reduce((t, h) => t + h, 0)}</small><br><small>Dòng 1/3/5: Huyền Thiết · Mật Ngân · Chu Sa Nguyên Khoáng (không phân hệ) · dòng 2/4/6: Khổng Tước · Phù Dung · Chung Nhũ Nguyên Thạch (đúng hệ món)</small><br>
        <small>Nguồn: <b>Lấy thuộc tính</b> từ đồ xanh (Lò rèn → Lò Ép Đồ, chọn được thuộc tính) · quái rơi: ${c("ore")} · phần thưởng phó bản · tách dòng đồ Tím</small></div>
      <div class="card"><b>Mảnh Hoàng Kim</b> <small class="dim">đang gom ${Object.keys(mats().shard).length} loại</small><br><small>Rơi: ${c("shard")}</small></div>
      <div class="card"><b>Thủy Tinh Trắng / Thần Bí Khoáng Thạch</b> <small class="dim">${matHave("misc", "wc")} / ${matHave("misc", "mys")}</small><br><small>Quái cấp ≥ 60 hoặc trùm. Rơi: ${c("wc")}</small></div>`;
  }
  modal(
    `<h3>Bách khoa</h3><div class="dtabs">${i.map(([c, t]) => `<button data-c="${c}" class="${c === codexTab ? "on" : ""}">${t}</button>`).join("")}</div><div class="codex">${a}</div>`,
    () => {
      document.querySelectorAll("#mBody .dtabs [data-c]").forEach((c) => (c.onclick = () => codexModal(c.dataset.c)));
    },
  );
}
