"use strict";
const DPS_WIN = 5;
function REC() {
  const n = S.rec || (S.rec = {});
  for (const e of [
    "maxHit",
    "maxDps",
    "fastBoss",
    "bestItem",
    "maxEnh",
    "bestStreak",
    "maxGoldKill",
    "wbBest",
    "horseLv",
  ])
    n[e] && typeof n[e] != "object" && delete n[e];
  return (
    (n.deaths = n.deaths | 0),
    (n.play = +n.play || 0),
    (n.goldKill = +n.goldKill || 0),
    (n.streak = n.streak | 0),
    (n.dgClear = n.dgClear || {}),
    (n.dgBest = n.dgBest || {}),
    (n.dgRank = n.dgRank || {}),
    (n.wbTries = n.wbTries | 0),
    (n.horses = n.horses | 0),
    n
  );
}
const recNow = () => Date.now();
function recSet(n, e, s, a = !0) {
  if (!S || !S.fac || !Number.isFinite(e)) return !1;
  const r = REC(),
    t = r[n];
  return t && (a ? e <= t.v : e >= t.v) ? !1 : ((r[n] = Object.assign({ v: e, t: recNow() }, s || {})), !0);
}
function recHit(n, e) {
  if (typeof PCTX < "u" && PCTX) return; // records are the main character's (js/party.js)
  R.quiet ||
    !(n > 0) ||
    ((R.dpsAcc = (R.dpsAcc || 0) + n),
    recSet("maxHit", Math.round(n), { n: e ? e.n : "", L: S.lvl }) &&
      !(R.recToastT > 0) &&
      REC().maxHit.v > 1e3 &&
      (addText(H.x, H.y - 64, "Kỷ lục đòn đánh!", "#ffd24a", 12), (R.recToastT = 20)));
}
function recTick(n) {
  if (((R.clock = (R.clock || 0) + n), R.quiet)) return;
  const e = REC();
  if (((e.play += n), (R.recToastT = (R.recToastT || 0) - n), (R.dpsT = (R.dpsT || 0) + n), R.dpsT >= 1)) {
    R.dpsT -= 1;
    const s = R.dpsWin || (R.dpsWin = []);
    (s.push(R.dpsAcc || 0),
      (R.dpsAcc = 0),
      s.length > 5 && s.shift(),
      s.length === 5 &&
        s.every((a) => a > 0) &&
        recSet("maxDps", Math.round(s.reduce((a, r) => a + r, 0) / 5), {
          L: S.lvl,
          n: R.P && R.P.main ? R.P.main.n : "",
        }));
  }
}
function recKill(n, e) {
  if (R.quiet || !S.fac) return;
  const s = REC();
  if (
    ((s.goldKill += e || 0),
    s.streak++,
    s.streak > ((s.bestStreak && s.bestStreak.v) || 0) && (s.bestStreak = { v: s.streak, t: recNow() }),
    e && recSet("maxGoldKill", e, { n: n.n }),
    n.cls === "boss" && n.born != null && !n.wb)
  ) {
    const a = (R.clock || 0) - n.born;
    a > 0.5 && recSet("fastBoss", Math.round(a * 10) / 10, { n: n.n, L: n.L }, !1);
  }
}
function recDeath() {
  if (!S.fac || R.quiet) return;
  const n = REC();
  (n.deaths++, (n.streak = 0));
}
function recItem(n) {
  if (!n || R.quiet || !S.fac) return;
  const e = REC(),
    s = e.bestItem,
    a = n.r * 1e3 + n.lvl * 10 + (n.mag || []).length;
  (!s || a > s.v) && (e.bestItem = { v: a, n: n.n, r: n.r, t: recNow() });
}
function recEnh(n) {
  n && n.enh && recSet("maxEnh", n.enh, { n: n.n });
}
const recDate = (n) => {
    if (!n) return "";
    const e = new Date(n),
      s = (a) => String(a).padStart(2, "0");
    return `${s(e.getDate())}/${s(e.getMonth() + 1)}/${e.getFullYear()}`;
  },
  recTime = (n) => {
    n = Math.round(n);
    const e = Math.floor(n / 3600),
      s = Math.floor((n % 3600) / 60);
    return e ? `${e} giờ ${s} phút` : `${s} phút ${n % 60} giây`;
  };
function recRows() {
  const n = REC(),
    e = RW().stat,
    s = (t, c) => (t ? c(t) : '<span class="dim">chưa có</span>'),
    a = (t) => (t && t.t ? `<small class="dim">${recDate(t.t)}</small>` : ""),
    r = typeof DUNGEONS < "u" ? DUNGEONS : [];
  return [
    [
      "Chiến đấu",
      [
        ["Đòn đánh mạnh nhất", s(n.maxHit, (t) => `<b>${fmt(t.v)}</b> ${t.n ? "· " + esc(t.n) : ""}`), a(n.maxHit)],
        ["DPS cao nhất (5 giây)", s(n.maxDps, (t) => `<b>${fmt(t.v)}</b>/giây`), a(n.maxDps)],
        ["Hạ trùm nhanh nhất", s(n.fastBoss, (t) => `<b>${t.v} giây</b> · ${esc(t.n)} Lv${t.L}`), a(n.fastBoss)],
        [
          "Chuỗi hạ quái không gục",
          s(n.bestStreak, (t) => `<b>${fmt(t.v)}</b> quái (hiện ${fmt(n.streak)})`),
          a(n.bestStreak),
        ],
        ["Ngân lượng 1 quái", s(n.maxGoldKill, (t) => `<b>${fmt(t.v)}</b> · ${esc(t.n)}`), a(n.maxGoldKill)],
        ["Số lần trọng thương", `<b>${fmt(n.deaths)}</b>`, ""],
      ],
    ],
    [
      "Tiến trình",
      [
        ["Bản đồ cao nhất", `<b>${esc(zoneOf(Math.min(S.maxStage, STAGES)).n)}</b>`, ""],
        [
          "Tổng quái đã hạ",
          `<b>${fmt(S.totalKills || 0)}</b> · trùm ${fmt(e.bosses)} · Hoàng Kim ${fmt(e.goldBoss)}`,
          "",
        ],
        ["Tháp thử thách", `<b>tầng ${e.towerBest}</b>`, ""],
        ["Chuyển sinh", `<b>${e.reborn}</b> lần`, ""],
        ["Thời gian chơi", `<b>${recTime(n.play)}</b>`, ""],
        ["Ngân lượng từ quái", `<b>${fmtL(n.goldKill)}</b>`, ""],
      ],
    ],
    [
      "Trang bị",
      [
        [
          "Món quý nhất từng có",
          s(n.bestItem, (t) => `<b style="color:${RAR_COL[t.r]}">${esc(t.n)}</b>`),
          a(n.bestItem),
        ],
        ["Cường hóa cao nhất", s(n.maxEnh, (t) => `<b>+${t.v}</b> · ${esc(t.n)}`), a(n.maxEnh)],
        ["Ngựa thuần dưỡng cao nhất", s(n.horseLv, (t) => `<b>cấp ${t.v}</b> · ${esc(t.n)}`), a(n.horseLv)],
        ["Sổ ngựa", `<b>${typeof horseBookCount == "function" ? horseBookCount() : 0}</b> loài đã cưỡi`, ""],
      ],
    ],
    [
      "Phó bản & Boss tuần",
      r
        .map((t) => [
          t.n,
          n.dgClear[t.id]
            ? `<b>${n.dgClear[t.id]}</b> lần · nhanh nhất ${n.dgBest[t.id]} giây · hạng ${n.dgRank[t.id] || "—"}`
            : '<span class="dim">chưa qua</span>',
          "",
        ])
        .concat([
          [
            "Boss tuần: sát thương cao nhất",
            s(n.wbBest, (t) => `<b>${fmt(t.v)}</b> · ${esc(t.n || "")} · hạng ${t.rank || "—"}`),
            a(n.wbBest),
          ],
          ["Boss tuần: số lượt đã đánh", `<b>${n.wbTries}</b>`, ""],
        ]),
    ],
  ];
}
function recordsBody() {
  return `<p class="desc">Kỷ lục riêng của nhân vật này (lưu trong file lưu). Đòn đánh và DPS chỉ tính khi đang chơi, không tính tiến trình vắng mặt.</p>
    ${recRows()
      .map(
        ([n, e]) =>
          `<h4 class="rech">${n}</h4><div class="card rect">${e.map(([s, a, r]) => `<span>${s}</span><span>${a} ${r}</span>`).join("")}</div>`,
      )
      .join("")}`;
}
