"use strict";
const J = window.JX,
  W = window.JW,
  $ = (n) => document.querySelector(n),
  rnd = (n, t) => n + Math.random() * (t - n),
  irnd = (n, t) => Math.floor(n + Math.random() * (t - n + 1)),
  pick = (n) => n[Math.floor(Math.random() * n.length)],
  clamp = (n, t, e) => Math.max(t, Math.min(e, n)),
  JX_K = 0.81,
  jxd = (n, t, e, s) => Math.hypot(e - n, (s - t) * 2) / JX_K,
  jxdE = (n, t) => jxd(n.x, n.y, t.x, t.y),
  fmtL = (n) => {
    if (((n = Math.round(+n || 0)), Math.abs(n) < 1e4)) return n.toLocaleString("vi-VN");
    const e = n / 1e4;
    return (
      (Math.abs(e) < 100 ? (Math.round(e * 10) / 10).toLocaleString("vi-VN") : Math.round(e).toLocaleString("vi-VN")) +
      " vạn"
    );
  },
  fmt = (n) => {
    n = Math.round(n);
    const t = Math.abs(n);
    return t < 1e4
      ? "" + n
      : t < 1e6
        ? (n / 1e3).toFixed(t < 1e5 ? 1 : 0) + "k"
        : t < 1e9
          ? (n / 1e6).toFixed(2) + "M"
          : (n / 1e9).toFixed(2) + "B";
  },
  esc = (n) => String(n).replace(/[&<>"]/g, (t) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[t]);
function wpick(n, t) {
  let e = 0;
  for (const o of n) e += t(o);
  let s = Math.random() * e;
  for (const o of n) if (((s -= t(o)), s <= 0)) return o;
  return n[n.length - 1];
}
const SERIES = J.series,
  SERIES_COL = ["#f3d35b", "#6fd46a", "#5fb8ff", "#ff6a3a", "#c8965a"],
  KHAC = { 0: 1, 1: 4, 4: 2, 2: 3, 3: 0 },
  counters = (n, t) => n >= 0 && t >= 0 && KHAC[n] === t,
  ELEM = ["phys", "poison", "cold", "fire", "light"],
  ELEM_VI = { phys: "Vật lý", poison: "Độc", cold: "Băng", fire: "Hỏa", light: "Lôi" },
  ELEM_COL = { phys: "#f0e6d0", poison: "#8fe34a", cold: "#7fd0ff", fire: "#ff7a2a", light: "#d9b6ff" },
  ELEM_ATTR = {
    phys: "physicsdamage_v",
    poison: "poisondamage_v",
    cold: "colddamage_v",
    fire: "firedamage_v",
    light: "lightingdamage_v",
  },
  ELEM_ADD = {
    phys: "addphysicsdamage_v",
    poison: "addpoisondamage_v",
    cold: "addcolddamage_v",
    fire: "addfiredamage_v",
    light: "addlightingdamage_v",
  },
  ELEM_RES = {
    phys: "physicsres_p",
    poison: "poisonres_p",
    cold: "coldres_p",
    fire: "fireres_p",
    light: "lightingres_p",
  },
  ELEM_ENH = { poison: "poisonenhance_p", cold: "coldenhance_p", fire: "fireenhance_p", light: "lightingenhance_p" },
  MAX_RESIST = 95,
  PLAYER_RES_MAX = 75,
  REBORN_RES = 2,
  MAX_HIT = 95,
  MIN_HIT = 40,
  CRIT_MULT = 2,
  STR_PER_DMG = 5,
  DEX_PER_DMG = 5,
  ENG_PER_DMG = 4,
  ENG_PER_PCT = 1,
  STR_PER_PCT = 1,
  DEX_PCT_RANGED = 1,
  IDLE_LIFE_PER_LEVEL = 0,
  PTS_PER_LEVEL = 5,
  SKILL_PTS_PER_LEVEL = 1,
  MAX_LEVEL = Math.min(200, J.exp.length),
  BASE_CAP = 200,
  levelCap = () => MAX_LEVEL,
  rebornN = () => (typeof S < "u" && S && S.rw && S.rw.stat && S.rw.stat.reborn) || 0,
  REB_EQ_LV = 200,
  eqLevel = () => S.lvl + REB_EQ_LV * rebornN(),
  ATTR_ID = Object.fromEntries(J.attr.map((n, t) => [n, t])),
  ATTR_SER_DMG = {
    metalskill_v: "addphysicsmagic_v",
    earthskill_v: "addpoisonmagic_v",
    woodskill_v: "addcoldmagic_v",
    waterskill_v: "addfiremagic_v",
    fireskill_v: "addlightingmagic_v",
  },
  attrReal = (n) => ATTR_SER_DMG[n] || n;
function skPlusText(n) {
  const t = Math.round(n[0] || 0),
    e = n[2] || 0;
  if (!(e > 0)) return `Tất cả kỹ năng: +${t} cấp`;
  const s = (typeof SK < "u" && SK[e]) || J.skills[e],
    o = typeof S < "u" && S && typeof FAC < "u" ? FAC[S.fac] : null,
    a = !o || (o.skills || []).some((c) => +c == +e);
  return `Kỹ năng ${s ? s.n : "#" + e}: +${t} cấp${a ? "" : " (không thuộc môn phái)"}`;
}
function attrText(n, t) {
  if (((n = attrReal(n)), n === "allskill_v")) return skPlusText(t);
  const e = J.attrDesc[n];
  return e
    ? e
        .replace(/#([a-zA-Z])([123A])([-+~%]?)/g, (s, o, a, c) => {
          const r = a === "A" ? Math.floor((t[0] || 0) / 256) : t[+a - 1] || 0;
          return o === "l" ? (J.skills[r] ? J.skills[r].n : "#" + r) : (c === "+" && r > 0 ? "+" : "") + r;
        })
        .replace(/#[a-zA-Z][123A][-+~]?/g, "")
        .replace(/Kỹ năng (\d+)/, (s, o) => (J.skills[o] ? "Kỹ năng " + J.skills[o].n : s))
    : n + ": " + t.filter((s) => s).join(" / ");
}
const FACTIONS = J.factions.filter((n) => n.skills && n.skills.length),
  FAC = Object.fromEntries(FACTIONS.map((n) => [n.key, n])),
  NOVICE_LV = 10;
for (let n = 0; n < 5; n++)
  FAC["vo" + n] = { key: "vo" + n, n: "Vô Môn Phái", series: n, skills: [], wcode: -1, id: -1, novice: !0 };
const isNovice = () => !!(S && FAC[S.fac] && FAC[S.fac].novice),
  FAC_SEX = { shaolin: 0, emei: 1, cuiyan: 1 },
  facAllowed = (n, t) => !(n.key in FAC_SEX) || FAC_SEX[n.key] === (t || 0);
function heroGfx(n = S && S.fac, t = S && S.sex) {
  if (W.hero[n]) return W.hero[n];
  const e = FAC[n];
  if (!e) return null;
  const s = FACTIONS.filter((a) => a.series === e.series),
    o = s.find((a) => facAllowed(a, t) && a.key in FAC_SEX) || s.find((a) => facAllowed(a, t)) || s[0];
  return t && !s.some((a) => FAC_SEX[a.key] === 1) ? W.hero.emei : W.hero[o.key];
}
const SK = J.skills;
for (const n of FACTIONS) {
  const t = n.skills
    .map((o) => SK[o])
    .filter(
      (o) =>
        o &&
        o.enemy &&
        [
          "physicsenhance_p",
          "physicsdamage_v",
          "poisondamage_v",
          "colddamage_v",
          "firedamage_v",
          "lightingdamage_v",
        ].some((a) => o.attr[a]),
    )
    .sort((o, a) => o.req - a.req || o.id - a.id);
  t.length && ((t[0].req = 1), (n.starter = t[0].id));
  const e = n.skills
      .map((o) => SK[o])
      .filter((o) => o && !o.enemy && o.attr.addphysicsdamage_p)
      .sort((o, a) => o.req - a.req || o.id - a.id)[0],
    s = e && e.attr.addphysicsdamage_p[0];
  n.wcode = Array.isArray(s) && [0, 1, 2, 3, 4, 5, 7, 9].includes(s[2]) ? s[2] : -1;
}
SK[384] && (SK[384].eqt = -2);
const EQT_VI = {
    "-1": "Tay không",
    0: "Kiếm",
    1: "Đao",
    2: "Côn",
    3: "Thương",
    4: "Song Chùy",
    5: "Song Đao",
    100: "Phi Tiêu",
    101: "Phi Đao",
    102: "Tụ Tiễn",
  },
  itEqt = (n) => (n ? (n.d === 1 ? 100 + n.k : n.k === 6 ? -1 : n.k) : -1),
  curEqt = () => itEqt(S.eq && S.eq.weapon),
  skEqt = (n) => (n && n.eqt != null && n.eqt !== -2 && n.attr && n.attr.physicsenhance_p ? n.eqt : null),
  skWOk = (n, t = curEqt()) => skEqt(n) === null || skEqt(n) === t;
function wantEqt() {
  const n = S.mainLock && S.main && S.main !== "basic" ? S.main : typeof R < "u" && R.P && R.P.wantId;
  return skEqt(SK[n]);
}
function weaponFits(n) {
  const t = wantEqt();
  if (t !== null) return itEqt(n) === t;
  const e = FAC[S.fac];
  return !e || e.wcode < 0 || weaponCode({ weapon: n }) === e.wcode;
}
function facWeaponDP(n) {
  const t = skEqt(SK[n.starter]);
  if (t !== null) return t === -1 ? [0, 6] : t >= 100 ? [1, t - 100] : [0, t];
  const e = n.wcode >= 0 ? n.wcode : 0;
  return e === 7 ? [1, 0] : [0, e === 9 ? 6 : e];
}
function wantWeaponDP() {
  const n = wantEqt();
  if (n !== null) return n === -1 ? [0, 6] : n >= 100 ? [1, n - 100] : [0, n];
  const t = FAC[S.fac],
    e = t && t.wcode >= 0 ? t.wcode : 0;
  return e === 7 ? [1, irnd(0, 2)] : [0, e === 9 ? 6 : e];
}
const SKV_FIXED = /^(skill_|missle_)/,
  SKV_EXTRA_MAX = 10,
  skVal = (n, t, e) => {
    const s = n.attr[t];
    if (!s) return null;
    const o = s.length,
      a = s[o - 1],
      c = (i) => (Array.isArray(i) ? i : [i, 0, 0]);
    if (e <= o || o < 2 || SKV_FIXED.test(t)) return c(s[clamp(e, 1, o) - 1]);
    const r = Math.min(SKV_EXTRA_MAX, e - o),
      d = c(s[o - 2]);
    return c(a).map((i, l) => (l === 1 && t.startsWith("poison") ? i : i + (i - d[l]) * r));
  },
  DMG_ATTRS = [
    "physicsenhance_p",
    "physicsdamage_v",
    "poisondamage_v",
    "colddamage_v",
    "firedamage_v",
    "lightingdamage_v",
  ],
  isAttack = (n) => !!(n && n.enemy && DMG_ATTRS.some((t) => n.attr[t])),
  ZONES = W.zones,
  MON = W.mon;
for (const n in W.anim || {})
  for (const t in W.anim[n]) {
    const e = W.anim[n][t];
    e && (e.ax < 0 || e.ay < 0 || e.ax > e.w || e.ay > e.h * 1.2) && ((e.ax = e.w / 2), (e.ay = e.h - 2));
  }
const ZONE_STAGES = 10,
  WAVES = 4,
  SERIES_ELEM = ["phys", "poison", "cold", "fire", "light"];
function monSeries(n) {
  const t = MON[n];
  if (!t) return 0;
  if (t._s !== void 0) return t._s;
  const e = t.rmax || [],
    s = Math.max(...e),
    o = e.map((a, c) => (a === s ? c : -1)).filter((a) => a >= 0);
  return (t._s = o.length === 1 ? o[0] : Math.abs(+n || 0) % 5);
}
function zoneSeries(n) {
  const t = [0, 0, 0, 0, 0];
  for (const e of n.m) t[monSeries(e)]++;
  return t;
}
const STAGES = ZONES.length * ZONE_STAGES,
  DMG_SHIELD_MAX = 0.35,
  SLOTS = [
    ["weapon", "Vũ khí"],
    ["armor", "Áo"],
    ["helm", "Mũ"],
    ["belt", "Đai lưng"],
    ["boot", "Giày"],
    ["cuff", "Hộ uyển"],
    ["amulet", "Dây chuyền"],
    ["ring1", "Nhẫn 1"],
    ["ring2", "Nhẫn 2"],
    ["pendant", "Ngọc bội"],
    ["horse", "Ngựa"],
  ],
  SLOT_VI = Object.fromEntries(SLOTS),
  DETAIL_SLOT = ["weapon", "weapon", "armor", "ring", "amulet", "boot", "belt", "helm", "cuff", "pendant", "horse"],
  MELEE_KIND = ["sword", "blade", "wand", "spear", "hammer", "dualblades"],
  RANGE_KIND = ["darts", "knife", "crossbow"],
  AFFIX_KEY = {
    armor: "armor",
    ring: "ring",
    amulet: "necklace",
    boot: "boot",
    belt: "belt",
    helm: "helm",
    cuff: "cuff",
    pendant: "pendant",
  },
  RAR_VI = ["Thường", "Xanh", "Hiếm", "Tím", "Hoàng Kim", "Bạch Kim"],
  RAR_COL = ["#e8e0d0", "#6aa8ff", "#ff9a3c", "#c77bff", "#ffcc00", "#9fe8ff"],
  INV_MAX = 60,
  ENH_MAX = 10,
  ENH_STEP = 0.08,
  PLAT_STEP = 0.05,
  ENH_LINE_STEP = 0.04,
  enhLineMul = (n) => 1 + ENH_LINE_STEP * ((n && n.enh) || 0),
  enhMul = (n) => 1 + ENH_STEP * ((n && n.enh) || 0) + PLAT_STEP * ((n && n.plv) || 0),
  WORLD = { w: 3072, h: 3072, pad: 20 },
  clampWorld = (n, t) => [clamp(n, WORLD.pad, WORLD.w - WORLD.pad), clamp(t, WORLD.pad + 30, WORLD.h - WORLD.pad)],
  inWorld = (n, t) => {
    const e = clampWorld(n, t);
    return typeof OBS < "u" && OBS.g ? obsSnap(e[0], e[1]) : e;
  },
  attrName = (n) => J.attr[n] || "#" + n,
  bossName = (n, t) => (MON[n] && /^Tiểu Boss/i.test(MON[n].n) ? `Bá Chủ ${t || ""}`.trim() : MON[n] ? MON[n].n : "");
